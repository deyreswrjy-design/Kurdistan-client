package dev.kurdistan.client.hud;

import dev.kurdistan.client.Config;
import dev.kurdistan.client.EditorScreen;
import dev.kurdistan.client.KurdistanClient;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.Identifier;

public final class HudRenderer {
    public static void register() {
        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT,
                Identifier.of(KurdistanClient.ID, "hud"), (ctx, tickCounter) -> {
                    dev.kurdistan.client.Features.frame(MinecraftClient.getInstance());
                    if (MinecraftClient.getInstance().currentScreen instanceof EditorScreen) return;
                    render(ctx, false);
                });
    }

    public static void render(DrawContext ctx, boolean editing) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        if (!editing && mc.options.hudHidden) return;

        HudModules.update();
        int sw = ctx.getScaledWindowWidth(), sh = ctx.getScaledWindowHeight();
        for (HudModule m : HudModules.ALL) {
            if (m.enabled()) drawModule(ctx, m, m.px(sw), m.py(sh));
        }
        if (HudModules.LOW_HEALTH.enabled()) HudModules.vignette(ctx);
    }

    /** Draws one module with its own scale, colors and opacity. */
    public static void drawModule(DrawContext ctx, HudModule m, int x, int y) {
        Config.Hud h = m.cfg();
        Ui.ovText = h.textColor <= 0 ? 0 : Theme.palette(h.textColor);
        Ui.ovBg = h.bg;
        Ui.ovOpacity = h.opacity;
        float s = m.scale();
        var mat = ctx.getMatrices();
        mat.pushMatrix();
        mat.translate((float) x, (float) y);
        mat.scale(s, s);
        try {
            m.draw(ctx, 0, 0);
        } finally {
            mat.popMatrix();
            Ui.ovText = 0;
            Ui.ovBg = 0;
            Ui.ovOpacity = -1;
        }
    }
}
