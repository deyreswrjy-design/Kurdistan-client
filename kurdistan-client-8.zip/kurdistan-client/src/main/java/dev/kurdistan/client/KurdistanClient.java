package dev.kurdistan.client;

import dev.kurdistan.client.hud.HudRenderer;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.gui.screen.TitleScreen;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;

public class KurdistanClient implements ClientModInitializer {
    public static final String ID = "kurdistan";

    @Override
    public void onInitializeClient() {
        Config.load();
        Keys.register();
        HudRenderer.register();
        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            if (screen instanceof TitleScreen && Config.I.customMenu) {
                client.send(() -> client.setScreen(new KurdistanTitleScreen()));
            }
        });
        ClientTickEvents.END_CLIENT_TICK.register(Features::tick);
        ClientLifecycleEvents.CLIENT_STOPPING.register(Features::shutdown);
    }
}
