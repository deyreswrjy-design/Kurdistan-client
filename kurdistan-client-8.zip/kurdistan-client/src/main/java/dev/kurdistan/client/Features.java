package dev.kurdistan.client;

import dev.kurdistan.client.mixin.SimpleOptionAccessor;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.option.Perspective;
import net.minecraft.client.option.SimpleOption;
import net.minecraft.util.Util;

public final class Features {
    public static boolean flActive;
    public static float flYaw, flPitch;

    private static Perspective savedPerspective;
    private static Double savedGamma;
    private static Integer savedFov;
    private static boolean zoomHeld;
    private static long zoomLast;
    private static double zoomCur;
    public static final int[] ZOOM_LEVELS = {15, 30, 45};
    private static boolean sprintForced;
    private static int appliedFps = 0;
    private static Integer origView, origBlend;
    private static Double origEntity;
    private static Object origParticles;

    public static final double[] CHAT_OPACITY = {0.25, 0.5, 0.75, 1.0};
    public static final double[] CHAT_SCALE = {0.5, 0.75, 1.0};
    public static final double[] CHAT_BG = {0.0, 0.25, 0.5, 1.0};

    /** Runs every rendered frame. */
    public static void frame(MinecraftClient mc) {
        if (mc.player != null) animateZoom(mc);
        if (mc.player != null && Config.I.hurtCam > 0) {
            mc.player.hurtTime = Config.I.hurtCam == 2 ? 0 : Math.min(mc.player.hurtTime, 5);
        }
    }

    public static void applyChat(MinecraftClient mc) {
        mc.options.getChatOpacity().setValue(CHAT_OPACITY[Math.floorMod(Config.I.chatOpacity, CHAT_OPACITY.length)]);
        mc.options.getChatScale().setValue(CHAT_SCALE[Math.floorMod(Config.I.chatScale, CHAT_SCALE.length)]);
        mc.options.getTextBackgroundOpacity().setValue(CHAT_BG[Math.floorMod(Config.I.chatBg, CHAT_BG.length)]);
    }

    public static void cycleGuiScale(MinecraftClient mc) {
        SimpleOption<Integer> g = mc.options.getGuiScale();
        g.setValue((g.getValue() + 1) % 5);
        mc.onResolutionChanged();
    }

    @SuppressWarnings("unchecked")
    private static <E extends Enum<E>> void applyParticles(SimpleOption<E> po) {
        String want = Config.I.particleMode == 1 ? "DECREASED" : Config.I.particleMode == 2 ? "MINIMAL" : null;
        if (want != null) {
            if (origParticles == null) origParticles = po.getValue();
            E target = Enum.valueOf(po.getValue().getDeclaringClass(), want);
            if (po.getValue() != target) po.setValue(target);
        } else if (origParticles != null) {
            po.setValue((E) origParticles);
            origParticles = null;
        }
    }

    private static void applyPerf(MinecraftClient mc) {
        applyParticles(mc.options.getParticles());

        int m = Config.I.fpsBoost;
        if (m != appliedFps) {
            SimpleOption<Integer> vd = mc.options.getViewDistance();
            SimpleOption<Integer> bl = mc.options.getBiomeBlendRadius();
            SimpleOption<Double> ed = mc.options.getEntityDistanceScaling();
            if (appliedFps == 0 || origView == null) {
                origView = vd.getValue();
                origBlend = bl.getValue();
                origEntity = ed.getValue();
            }
            if (m == 0) {
                vd.setValue(origView);
                bl.setValue(origBlend);
                ed.setValue(origEntity);
            } else {
                vd.setValue(Math.min(origView, m == 1 ? 10 : 6));
                bl.setValue(Math.min(origBlend, m == 1 ? 1 : 0));
                ed.setValue(Math.min(origEntity, m == 1 ? 0.75 : 0.5));
            }
            appliedFps = m;
        }
    }

    public static void shutdown(MinecraftClient mc) {
        restore(mc);
        Xray.active = false;
        Xray.culling(mc, true);
        if (mc.options == null) return;
        if (origParticles != null) { Config.I.particleMode = 0; applyParticles(mc.options.getParticles()); }
        if (appliedFps != 0 && origView != null) {
            mc.options.getViewDistance().setValue(origView);
            mc.options.getBiomeBlendRadius().setValue(origBlend);
            mc.options.getEntityDistanceScaling().setValue(origEntity);
            appliedFps = 0;
        }
    }

    public static void tick(MinecraftClient mc) {
        if (mc.player == null || mc.world == null) {
            flActive = false;
            zoomHeld = false;
            restore(mc);
            Pops.reset();
            Xray.active = false;
            return;
        }

        while (Keys.MENU.wasPressed()) mc.setScreen(new EditorScreen());
        while (Keys.FULLBRIGHT.wasPressed()) {
            Config.I.fullbright = !Config.I.fullbright;
            Config.save();
        }

        boolean screenOpen = mc.currentScreen != null
                && !(mc.currentScreen instanceof ChatScreen)
                && !(mc.currentScreen instanceof EditorScreen);

        // Freelook
        boolean wantLook = Config.I.freelook && Keys.FREELOOK.isPressed() && mc.currentScreen == null;
        if (wantLook && !flActive) {
            flActive = true;
            flYaw = mc.player.getYaw();
            flPitch = mc.player.getPitch();
            savedPerspective = mc.options.getPerspective();
            mc.options.setPerspective(Perspective.THIRD_PERSON_BACK);
        } else if (!wantLook && flActive) {
            flActive = false;
            if (savedPerspective != null) mc.options.setPerspective(savedPerspective);
        }

        // Xray (singleplayer only)
        boolean wantXray = Config.I.xray && mc.isInSingleplayer();
        if (wantXray != Xray.active) Xray.refresh();

        // Fullbright (brightness raised while playing; restored whenever a menu opens or you quit)
        SimpleOption<Double> gamma = mc.options.getGamma();
        if ((Config.I.fullbright || (Xray.active && Config.I.xrayBright)) && !screenOpen) {
            if (savedGamma == null) savedGamma = gamma.getValue();
            raw(gamma, 15.0);
        } else if (savedGamma != null) {
            raw(gamma, savedGamma);
            savedGamma = null;
        }

        // Toggle Sprint
        if (Config.I.toggleSprint && mc.currentScreen == null
                && mc.options.forwardKey.isPressed() && !mc.player.isSneaking()) {
            mc.options.sprintKey.setPressed(true);
            sprintForced = true;
        } else if (sprintForced) {
            mc.options.sprintKey.setPressed(false);
            sprintForced = false;
        }

        applyPerf(mc);

        // Zoom (animated)
        zoomHeld = Config.I.zoom && Keys.ZOOM.isPressed() && !screenOpen && mc.currentScreen == null;
        animateZoom(mc);
    }

    private static void animateZoom(MinecraftClient mc) {
        long now = Util.getMeasuringTimeMs();
        long dt = zoomLast == 0 ? 16 : Math.min(100, now - zoomLast);
        zoomLast = now;
        SimpleOption<Integer> fov = mc.options.getFov();
        if (zoomHeld && savedFov == null) {
            savedFov = fov.getValue();
            zoomCur = savedFov;
        }
        if (savedFov == null) return;
        double target = zoomHeld ? ZOOM_LEVELS[Math.floorMod(Config.I.zoomLevel, ZOOM_LEVELS.length)] : savedFov;
        if (Config.I.smoothZoom) zoomCur += (target - zoomCur) * (1.0 - Math.exp(-dt / 70.0));
        else zoomCur = target;
        if (!zoomHeld && Math.abs(zoomCur - savedFov) < 0.6) {
            raw(fov, savedFov);
            savedFov = null;
            return;
        }
        raw(fov, (int) Math.round(zoomCur));
    }

    public static void restore(MinecraftClient mc) {
        if (mc.options == null) return;
        if (savedGamma != null) { raw(mc.options.getGamma(), savedGamma); savedGamma = null; }
        if (savedFov != null) { raw(mc.options.getFov(), savedFov); savedFov = null; }
    }

    @SuppressWarnings("unchecked")
    private static <T> void raw(SimpleOption<T> option, T value) {
        ((SimpleOptionAccessor<T>) (Object) option).kurdistan$setValue(value);
    }
}
