package dev.kurdistan.client;

import dev.kurdistan.client.hud.Theme;
import dev.kurdistan.client.hud.Ui;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

/** Branding drawn over the vanilla title screen. */
public final class MainMenu {
    public static void draw(DrawContext c) {
        TextRenderer tr = MinecraftClient.getInstance().textRenderer;
        if (tr == null) return;
        int w = c.getScaledWindowWidth(), h = c.getScaledWindowHeight();
        c.fill(0, 0, w, h, Theme.accentA(0x16));
        c.fill(0, h - 24, w, h, 0x66000000);

        int x = 8, y = 8;
        int pw = 118, ph = 34;
        Ui.rect(c, x, y, pw, ph, 0xAA0A0A0F);
        Ui.accentLine(c, x, y, pw);
        c.drawText(tr, "KURDISTAN CLIENT", x + 8, y + 9, Theme.accent(), true);
        c.drawText(tr, "by Kurdistan Developer", x + 8, y + 21, 0xFFB8B8C8, true);

        String hint = "Press Right Shift in a world to open the menu";
        c.drawText(tr, hint, (w - tr.getWidth(hint)) / 2, h - 16, 0xFFB8B8C8, true);
    }
}
