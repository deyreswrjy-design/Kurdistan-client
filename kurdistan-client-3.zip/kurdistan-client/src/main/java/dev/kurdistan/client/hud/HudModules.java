package dev.kurdistan.client.hud;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.client.option.GameOptions;
import net.minecraft.util.Util;
import net.minecraft.util.math.MathHelper;

import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.ItemStack;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.Items;

import java.util.function.IntSupplier;
import java.util.ArrayDeque;
import java.util.List;
import java.util.function.Supplier;

public final class HudModules {
    public static final List<HudModule> ALL = List.of(
            new TextModule("fps", "FPS", 4, 4, true,
                    () -> "FPS: " + MinecraftClient.getInstance().getCurrentFps()),
            new TextModule("cps", "CPS", 4, 22, true,
                    HudModules::cpsText),
            new TextModule("ping", "Ping", 4, 40, false, HudModules::pingText),
            new TextModule("coords", "Coords", 4, 58, false, HudModules::coordsText),
            new Keystrokes(),
            new MouseStrokes(),
            new ArmorStatus(),
            new Effects(),
            new TextModule("clock", "Clock", 4, 94, false, HudModules::clockText),
            new TextModule("direction", "Direction", 4, 112, false, HudModules::directionText),
            new TextModule("speed", "Speed", 4, 130, false, HudModules::speedText),
            new TextModule("memory", "Memory", 4, 148, false, HudModules::memoryText),
            new TextModule("health", "Health", 100, 4, false, HudModules::healthText),
            new TextModule("xp", "XP Level", 100, 22, false, HudModules::xpText),
            new TextModule("target", "Target Block", 100, 40, false, HudModules::targetText),
            new TextModule("playtime", "Playtime", 100, 58, false, HudModules::playtimeText),
            new TextModule("server", "Server", 100, 76, false, HudModules::serverText),
            new TextModule("players", "Players", 100, 94, false, HudModules::playersText),
            new TextModule("held", "Held Item", 100, 112, false, HudModules::heldText),
            new TextModule("status", "Status", 100, 130, false, HudModules::statusText),
            new TextModule("crystals", "Crystals", 200, 4, false, () -> "Crystals: " + count(Items.END_CRYSTAL)),
            new TextModule("anchors", "Anchors", 200, 22, false, () -> "Anchors: " + count(Items.RESPAWN_ANCHOR)),
            new TextModule("glowstone", "Glowstone", 200, 40, false, () -> "Glowstone: " + count(Items.GLOWSTONE)),
            new TextModule("obsidian", "Obsidian", 200, 58, false, () -> "Obsidian: " + count(Items.OBSIDIAN)),
            new TextModule("totems", "Totems", 200, 76, false, () -> "Totems: " + count(Items.TOTEM_OF_UNDYING)),
            new TextModule("pops", "Totem Pops", 200, 94, false, HudModules::popsText),
            new TextModule("durability", "Durability Warn", 200, 112, false, HudModules::durabilityText, HudModules::durabilityColor),
            new TextModule("armorbreak", "Armor Break Warn", 200, 130, false, HudModules::armorBreakText, HudModules::armorBreakColor),
            new LowHealth(),
            new InventoryHud()
    );

    private static final long START = Util.getMeasuringTimeMs();

    // ---- per-frame trackers ----
    private static final ArrayDeque<Long> left = new ArrayDeque<>(), right = new ArrayDeque<>();
    private static boolean prevL, prevR;
    private static final ArrayDeque<float[]> trail = new ArrayDeque<>();
    private static float lastYaw, lastPitch, sx, sy;
    private static boolean mouseInit;
    private static double lastX, lastZ, speed;
    private static long lastT;

    public static void update() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        GameOptions o = mc.options;

        long now = Util.getMeasuringTimeMs();
        boolean l = o.attackKey.isPressed(), r = o.useKey.isPressed();
        if (l && !prevL) left.add(now);
        if (r && !prevR) right.add(now);
        prevL = l;
        prevR = r;
        while (!left.isEmpty() && now - left.peekFirst() > 1000) left.pollFirst();
        while (!right.isEmpty() && now - right.peekFirst() > 1000) right.pollFirst();

        float yaw = dev.kurdistan.client.Features.flActive ? dev.kurdistan.client.Features.flYaw : mc.player.getYaw();
        float pitch = dev.kurdistan.client.Features.flActive ? dev.kurdistan.client.Features.flPitch : mc.player.getPitch();
        if (!mouseInit) { lastYaw = yaw; lastPitch = pitch; mouseInit = true; }
        float dx = MathHelper.wrapDegrees(yaw - lastYaw), dy = pitch - lastPitch;
        lastYaw = yaw;
        lastPitch = pitch;
        sx = MathHelper.clamp(sx * 0.85f + dx * 0.6f, -22f, 22f);
        sy = MathHelper.clamp(sy * 0.85f + dy * 0.6f, -22f, 22f);
        long dt = now - lastT;
        if (lastT == 0) { lastX = mc.player.getX(); lastZ = mc.player.getZ(); lastT = now; }
        else if (dt >= 100) {
            double d = Math.hypot(mc.player.getX() - lastX, mc.player.getZ() - lastZ);
            double v = d / dt * 1000.0;
            speed = v > 100 ? 0 : speed * 0.6 + v * 0.4;
            lastX = mc.player.getX(); lastZ = mc.player.getZ(); lastT = now;
        }
        trail.addFirst(new float[]{sx, sy});
        while (trail.size() > 22) trail.removeLast();
    }

    private static String clockText() {
        return "Time: " + LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss"));
    }

    private static String directionText() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return "Facing: -";
        String[] names = {"S", "SW", "W", "NW", "N", "NE", "E", "SE"};
        int i = Math.floorMod(Math.round(MathHelper.wrapDegrees(mc.player.getYaw()) / 45f), 8);
        return "Facing: " + names[i];
    }

    private static String speedText() {
        return String.format("Speed: %.1f b/s", speed);
    }

    private static String memoryText() {
        Runtime r = Runtime.getRuntime();
        long used = (r.totalMemory() - r.freeMemory()) / 1048576L;
        return "Mem: " + used + " / " + (r.maxMemory() / 1048576L) + " MB";
    }

    private static final EquipmentSlot[] ARMOR = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
    private static final String[] ARMOR_NAMES = {"Helmet", "Chestplate", "Leggings", "Boots"};

    private static int count(Item item) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return 0;
        PlayerInventory inv = mc.player.getInventory();
        int n = 0;
        for (int i = 0; i < inv.size(); i++) {
            ItemStack st = inv.getStack(i);
            if (st.isOf(item)) n += st.getCount();
        }
        return n;
    }

    private static String lowArmor(int threshold) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return null;
        String worst = null;
        int worstPct = 101;
        for (int i = 0; i < 4; i++) {
            ItemStack st = mc.player.getEquippedStack(ARMOR[i]);
            if (st.isEmpty() || !st.isDamageable() || st.getMaxDamage() <= 0) continue;
            int pct = (st.getMaxDamage() - st.getDamage()) * 100 / st.getMaxDamage();
            if (pct < threshold && pct < worstPct) { worstPct = pct; worst = ARMOR_NAMES[i] + " " + pct + "%"; }
        }
        return worst;
    }

    private static String popsText() {
        String s = "Pops: " + dev.kurdistan.client.Pops.self;
        if (!dev.kurdistan.client.Pops.last.isEmpty())
            s += " | " + dev.kurdistan.client.Pops.last + " x" + dev.kurdistan.client.Pops.lastCount;
        return s;
    }

    private static String durabilityText() {
        String w = lowArmor(20);
        return w == null ? "Durability: OK" : "Low durability: " + w;
    }

    private static int durabilityColor() { return lowArmor(20) == null ? 0xFF8A8A9A : 0xFFFFAA00; }

    private static String armorBreakText() {
        String w = lowArmor(6);
        return w == null ? "Armor break: safe" : "ARMOR BREAKING: " + w;
    }

    private static int armorBreakColor() {
        if (lowArmor(6) == null) return 0xFF8A8A9A;
        return (Util.getMeasuringTimeMs() / 250) % 2 == 0 ? 0xFFFF3030 : 0xFFFFFFFF;
    }

    private static boolean lowHealth() {
        MinecraftClient mc = MinecraftClient.getInstance();
        return mc.player != null && mc.player.getHealth() <= 6f;
    }

    private static String healthText() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return "HP: -";
        return "HP: " + Math.round(mc.player.getHealth()) + "  Food: " + mc.player.getHungerManager().getFoodLevel();
    }

    private static String xpText() {
        MinecraftClient mc = MinecraftClient.getInstance();
        return "XP Level: " + (mc.player == null ? 0 : mc.player.experienceLevel);
    }

    private static String targetText() {
        MinecraftClient mc = MinecraftClient.getInstance();
        HitResult h = mc.crosshairTarget;
        if (mc.world != null && h instanceof BlockHitResult b && h.getType() == HitResult.Type.BLOCK) {
            return "Target: " + mc.world.getBlockState(b.getBlockPos()).getBlock().getName().getString();
        }
        return "Target: -";
    }

    private static String playtimeText() {
        long s = (Util.getMeasuringTimeMs() - START) / 1000L;
        return String.format("Playtime: %d:%02d:%02d", s / 3600, (s / 60) % 60, s % 60);
    }

    private static String serverText() {
        ServerInfo si = MinecraftClient.getInstance().getCurrentServerEntry();
        return si == null ? "Singleplayer" : si.address;
    }

    private static String playersText() {
        ClientPlayNetworkHandler h = MinecraftClient.getInstance().getNetworkHandler();
        return "Players: " + (h == null ? 0 : h.getPlayerList().size());
    }

    private static String heldText() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.player.getMainHandStack().isEmpty()) return "Hand: -";
        return "Hand: " + mc.player.getMainHandStack().getName().getString();
    }

    private static String statusText() {
        List<String> on = new ArrayList<>();
        if (dev.kurdistan.client.Features.flActive) on.add("Freelook");
        if (dev.kurdistan.client.Config.I.fullbright) on.add("Fullbright");
        if (dev.kurdistan.client.Config.I.toggleSprint) on.add("Sprint");
        if (dev.kurdistan.client.Keys.ZOOM.isPressed()) on.add("Zoom");
        return on.isEmpty() ? "Status: idle" : String.join(" | ", on);
    }

    private static String cpsText() {
        return "CPS: " + left.size() + " | " + right.size();
    }

    private static String pingText() {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayNetworkHandler h = mc.getNetworkHandler();
        if (h == null || mc.player == null) return "Ping: -";
        PlayerListEntry e = h.getPlayerListEntry(mc.player.getUuid());
        return "Ping: " + (e == null ? 0 : e.getLatency()) + " ms";
    }

    private static String coordsText() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return "XYZ: -";
        return "XYZ: " + mc.player.getBlockX() + " / " + mc.player.getBlockY() + " / " + mc.player.getBlockZ();
    }

    // ---- modules ----
    static class TextModule extends HudModule {
        private final Supplier<String> text;
        private final IntSupplier color;

        TextModule(String id, String name, int x, int y, boolean en, Supplier<String> text) {
            this(id, name, x, y, en, text, null);
        }

        TextModule(String id, String name, int x, int y, boolean en, Supplier<String> text, IntSupplier color) {
            super(id, name, x, y, en);
            this.text = text;
            this.color = color;
        }

        @Override public int width() { return Ui.tr().getWidth(text.get()) + 10; }
        @Override public int height() { return 15; }

        @Override
        public void draw(DrawContext c, int x, int y) {
            Ui.panel(c, x, y, width(), height());
            if (color == null) Ui.text(c, text.get(), x + 5, y + 4);
            else Ui.text(c, text.get(), x + 5, y + 4, color.getAsInt());
        }
    }

    static final class LowHealth extends TextModule {
        LowHealth() {
            super("lowhealth", "Low Health Warn", 200, 148, false,
                    () -> lowHealth() ? "LOW HEALTH: " + Math.round(MinecraftClient.getInstance().player.getHealth()) : "Health: OK",
                    () -> !lowHealth() ? 0xFF8A8A9A : ((Util.getMeasuringTimeMs() / 250) % 2 == 0 ? 0xFFFF3030 : 0xFFFFFFFF));
        }

        @Override
        public void draw(DrawContext c, int x, int y) {
            super.draw(c, x, y);
            if (!lowHealth()) return;
            int sw = c.getScaledWindowWidth(), sh = c.getScaledWindowHeight();
            int a = (int) (70 + 60 * Math.sin(Util.getMeasuringTimeMs() / 150.0));
            int col = (Math.max(20, a) << 24) | 0xFF0000;
            int t = 6;
            c.fill(0, 0, sw, t, col);
            c.fill(0, sh - t, sw, sh, col);
            c.fill(0, t, t, sh - t, col);
            c.fill(sw - t, t, sw, sh - t, col);
        }
    }

    static final class InventoryHud extends HudModule {
        InventoryHud() { super("inventory", "Inventory HUD", 4, 4, false); }

        @Override public int width() { return 9 * 18 + 4; }
        @Override public int height() { return 3 * 18 + 4; }

        @Override
        public void draw(DrawContext c, int x, int y) {
            MinecraftClient mc = MinecraftClient.getInstance();
            Ui.panel(c, x, y, width(), height());
            if (mc.player == null) return;
            PlayerInventory inv = mc.player.getInventory();
            for (int i = 0; i < 27; i++) {
                ItemStack st = inv.getStack(9 + i);
                if (st.isEmpty()) continue;
                int ix = x + 2 + (i % 9) * 18 + 1, iy = y + 2 + (i / 9) * 18 + 1;
                c.drawItem(st, ix, iy);
                c.drawStackOverlay(Ui.tr(), st, ix, iy);
            }
        }
    }

    static final class Keystrokes extends HudModule {
        private static final int S = 20, G = 2;

        Keystrokes() { super("keystrokes", "Keystrokes", 4, 80, true); }

        @Override public int width() { return 3 * S + 2 * G; }
        @Override public int height() { return 3 * (S + G) + 12; }

        @Override
        public void draw(DrawContext c, int x, int y) {
            GameOptions o = MinecraftClient.getInstance().options;
            key(c, x + S + G, y, S, S, "W", o.forwardKey.isPressed());
            key(c, x, y + S + G, S, S, "A", o.leftKey.isPressed());
            key(c, x + S + G, y + S + G, S, S, "S", o.backKey.isPressed());
            key(c, x + 2 * (S + G), y + S + G, S, S, "D", o.rightKey.isPressed());
            int half = (width() - G) / 2;
            key(c, x, y + 2 * (S + G), half, S, "LMB", o.attackKey.isPressed());
            key(c, x + half + G, y + 2 * (S + G), width() - half - G, S, "RMB", o.useKey.isPressed());
            key(c, x, y + 3 * (S + G), width(), 12, "", o.jumpKey.isPressed());
            int lc = o.jumpKey.isPressed() ? 0xFFFFFFFF : Theme.text();
            c.fill(x + 18, y + 3 * (S + G) + 5, x + width() - 18, y + 3 * (S + G) + 7, lc);
        }

        private static void key(DrawContext c, int x, int y, int w, int h, String label, boolean down) {
            Ui.rect(c, x, y, w, h, down ? Theme.accentA(0xE0) : Theme.bg());
            if (!label.isEmpty()) {
                int tw = Ui.tr().getWidth(label);
                c.drawText(Ui.tr(), label, x + (w - tw) / 2, y + (h - 8) / 2 + 1,
                        down ? 0xFFFFFFFF : Theme.text(), true);
            }
        }
    }

    static final class MouseStrokes extends HudModule {
        MouseStrokes() { super("mousestrokes", "Mouse Strokes", 80, 80, true); }

        @Override public int width() { return 54; }
        @Override public int height() { return 54; }

        @Override
        public void draw(DrawContext c, int x, int y) {
            Ui.panel(c, x, y, width(), height());
            int cx = x + width() / 2, cy = y + height() / 2 + 1;
            c.fill(cx, y + 4, cx + 1, y + height() - 4, 0x33FFFFFF);
            c.fill(x + 4, cy, x + width() - 4, cy + 1, 0x33FFFFFF);
            int i = 0, n = trail.size();
            for (float[] p : trail) {
                int a = (int) (255f * (1f - (float) i / n));
                int col = (a << 24) | 0xFFFFFF;
                int r = i == 0 ? 2 : 1;
                int px = cx + Math.round(p[0]), py = cy + Math.round(p[1]);
                c.fill(px - r, py - r, px + r, py + r, col);
                i++;
            }
        }
    }
    static final class ArmorStatus extends HudModule {
        private static final EquipmentSlot[] SLOTS = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};

        ArmorStatus() { super("armor", "Armor", 4, 164, true); }

        @Override public int width() { return 62; }
        @Override public int height() { return 5 * 18 + 2; }

        @Override
        public void draw(DrawContext c, int x, int y) {
            MinecraftClient mc = MinecraftClient.getInstance();
            Ui.panel(c, x, y, width(), height());
            if (mc.player == null) return;
            for (int i = 0; i < 5; i++) {
                ItemStack st = i < 4 ? mc.player.getEquippedStack(SLOTS[i]) : mc.player.getMainHandStack();
                int ry = y + 2 + i * 18;
                if (st.isEmpty()) continue;
                c.drawItem(st, x + 3, ry);
                String t = null;
                if (st.isDamageable()) t = String.valueOf(st.getMaxDamage() - st.getDamage());
                else if (st.getCount() > 1) t = "x" + st.getCount();
                if (t != null) Ui.text(c, t, x + 22, ry + 5);
            }
        }
    }

    static final class Effects extends HudModule {
        Effects() { super("effects", "Potions", 330, 4, true); }

        private static String fmt(int ticks) {
            int s = ticks / 20;
            return String.format("%d:%02d", s / 60, s % 60);
        }

        private List<String> lines() {
            List<String> out = new ArrayList<>();
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player != null) {
                for (StatusEffectInstance e : mc.player.getStatusEffects()) {
                    String n = e.getEffectType().value().getName().getString();
                    int amp = e.getAmplifier();
                    out.add(n + (amp > 0 ? " " + (amp + 1) : "") + "  " + (e.isInfinite() ? "inf" : fmt(e.getDuration())));
                }
            }
            if (out.isEmpty()) out.add("No effects");
            return out;
        }

        @Override
        public int width() {
            int w = 0;
            for (String l : lines()) w = Math.max(w, Ui.tr().getWidth(l));
            return w + 10;
        }

        @Override public int height() { return lines().size() * 11 + 6; }

        @Override
        public void draw(DrawContext c, int x, int y) {
            Ui.panel(c, x, y, width(), height());
            int i = 0;
            for (String l : lines()) Ui.text(c, l, x + 5, y + 5 + i++ * 11);
        }
    }
}
