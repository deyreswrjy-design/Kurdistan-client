# Kurdistan Client (Fabric, Minecraft Java 1.21.11)

Features: Freelook (hold LEFT ALT), Fullbright (toggle G), Zoom (hold C),
Toggle Sprint (menu toggle).
Custom theme: accent colors (incl. Rainbow), background, opacity, text color, rounded corners.
HUD: FPS, CPS, Ping, Coords, Keystrokes, Mouse Strokes, Armor Status, Potion Effects, Clock, Direction, Speed, Memory, Health, XP Level, Target Block, Playtime, Server, Players, Held Item, Status.
Press RIGHT SHIFT to open the HUD editor: drag any module anywhere, toggle features/modules.
Loading screen shows "KURDISTAN DEVELOPER" instead of Mojang Studios.
Settings are saved in .minecraft/config/kurdistan_client.json.

## Build the jar
1. Install JDK 21 and Gradle 9.x (only needed once, to create the wrapper).
2. Windows: double-click build.bat   |   Mac/Linux: ./build.sh
3. Jar appears in build/libs/kurdistan-client-1.0.0.jar (not the -sources one).

## Install
Minecraft 1.21.11 + Fabric Loader 0.18.1+ + Fabric API 0.141.1+1.21.11, put both jars in .minecraft/mods.

If Gradle says a version doesn't exist, copy the right numbers from https://fabricmc.net/develop into gradle.properties.

## v1.2 additions
CPvP: Crystals/Anchors/Glowstone/Obsidian/Totems counters, Totem Pops, Durability + Armor Break warnings, Low Health warning (red screen edge), Inventory HUD.
Main tab: Low Fire, No Weather, Hurt Cam (Full/Half/None), Particles (Normal/Reduced/Minimal), FPS Boost.
Theme tab: Custom Menu (title screen branding), Chat Opacity/Scale/BG, GUI Scale.
Mods tab: module search. Client tab: Toggle All, Reset Positions, Save/Load Profile 1-3.

## v1.3 additions
Fully custom main menu (Singleplayer / Multiplayer / Options / Quit) with animated background (toggle: Theme > Custom Menu).
Item Physics (experimental): dropped items lie flat. Game tab: FOV, Max FPS, FOV Effects, View Bobbing, VSync, Entity Shadows.
New HUD modules: Date, Light Level, Chunk, Nether Coords, Armor Points, Move State, Fall Distance, Target Entity.
