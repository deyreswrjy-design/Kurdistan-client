package dev.kurdistan.client;

import dev.kurdistan.client.hud.HudModule;
import dev.kurdistan.client.hud.HudModules;
import dev.kurdistan.client.hud.HudRenderer;
import dev.kurdistan.client.hud.Theme;
import dev.kurdistan.client.hud.Ui;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Util;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.Supplier;

/** Custom-drawn menu: tabs, theme, features, module toggles + search, profiles and drag-and-drop HUD editing. */
public class EditorScreen extends Screen {
    private static final int BW = 96, BH = 16, GAP = 3, PAD = 6, TITLE_H = 16, TAB_H = 16;
    private static final String[] TABS = {"Main", "Theme", "Mods", "Game", "Client"};
    private static final String[] HURT = {"Full", "Half", "None"};
    private static final String[] PART = {"Normal", "Reduced", "Minimal"};
    private static final String[] FPS = {"Off", "Balanced", "Max"};
    private static int tab;
    private static boolean collapsed;
    private static String filter = "";
    private static String toast = "";
    private static long toastUntil;

    private record Item(int tab, Supplier<String> label, BooleanSupplier on, Runnable action) {}

    private final List<Item> items = new ArrayList<>();
    private final List<int[]> rects = new ArrayList<>(); // x, y, w, h, itemIndex
    private int px, py, pw, ph, tabW;
    private TextFieldWidget search;

    private HudModule dragging;
    private int offX, offY;
    private boolean wasDown = true;

    public EditorScreen() {
        super(Text.literal("Kurdistan Client"));

        // ---- Main
        toggle(0, "Freelook", () -> Config.I.freelook, v -> Config.I.freelook = v);
        toggle(0, "Fullbright", () -> Config.I.fullbright, v -> Config.I.fullbright = v);
        toggle(0, "Zoom", () -> Config.I.zoom, v -> Config.I.zoom = v);
        toggle(0, "Toggle Sprint", () -> Config.I.toggleSprint, v -> Config.I.toggleSprint = v);
        toggle(0, "Low Fire", () -> Config.I.lowFire, v -> Config.I.lowFire = v);
        toggle(0, "No Weather", () -> Config.I.noWeather, v -> Config.I.noWeather = v);
        toggle(0, "Item Physics", () -> Config.I.itemPhysics, v -> Config.I.itemPhysics = v);
        cycle(0, "Hurt Cam", () -> HURT[Math.floorMod(Config.I.hurtCam, 3)], () -> Config.I.hurtCam = (Config.I.hurtCam + 1) % 3);
        cycle(0, "Particles", () -> PART[Math.floorMod(Config.I.particleMode, 3)], () -> Config.I.particleMode = (Config.I.particleMode + 1) % 3);
        cycle(0, "FPS Boost", () -> FPS[Math.floorMod(Config.I.fpsBoost, 3)], () -> Config.I.fpsBoost = (Config.I.fpsBoost + 1) % 3);

        // ---- Theme
        cycle(1, "Accent", () -> Theme.ACCENT_NAMES[Math.floorMod(Config.I.accent, Theme.ACCENT_NAMES.length)],
                () -> Config.I.accent = (Config.I.accent + 1) % Theme.ACCENT_NAMES.length);
        cycle(1, "Background", () -> Theme.BG_NAMES[Math.floorMod(Config.I.bgColor, Theme.BG_NAMES.length)],
                () -> Config.I.bgColor = (Config.I.bgColor + 1) % Theme.BG_NAMES.length);
        cycle(1, "BG Opacity", () -> Config.I.bgOpacity + "%",
                () -> Config.I.bgOpacity = ((Config.I.bgOpacity / 20 + 1) % 6) * 20);
        cycle(1, "Text", () -> Theme.TEXT_NAMES[Math.floorMod(Config.I.textColor, Theme.TEXT_NAMES.length)],
                () -> Config.I.textColor = (Config.I.textColor + 1) % Theme.TEXT_NAMES.length);
        cycle(1, "Corners", () -> Config.I.rounded ? "Rounded" : "Square", () -> Config.I.rounded = !Config.I.rounded);
        toggle(1, "Custom Menu", () -> Config.I.customMenu, v -> Config.I.customMenu = v);
        cycle(1, "Chat Opacity", () -> pct(Features.CHAT_OPACITY[Math.floorMod(Config.I.chatOpacity, Features.CHAT_OPACITY.length)]),
                () -> { Config.I.chatOpacity = (Config.I.chatOpacity + 1) % Features.CHAT_OPACITY.length; Features.applyChat(client); });
        cycle(1, "Chat Scale", () -> pct(Features.CHAT_SCALE[Math.floorMod(Config.I.chatScale, Features.CHAT_SCALE.length)]),
                () -> { Config.I.chatScale = (Config.I.chatScale + 1) % Features.CHAT_SCALE.length; Features.applyChat(client); });
        cycle(1, "Chat BG", () -> pct(Features.CHAT_BG[Math.floorMod(Config.I.chatBg, Features.CHAT_BG.length)]),
                () -> { Config.I.chatBg = (Config.I.chatBg + 1) % Features.CHAT_BG.length; Features.applyChat(client); });
        cycle(1, "GUI Scale", () -> {
            int g = client == null ? 0 : client.options.getGuiScale().getValue();
            return g == 0 ? "Auto" : String.valueOf(g);
        }, () -> client.send(() -> Features.cycleGuiScale(client)));

        // ---- Game (vanilla options, one tap)
        cycle(3, "FOV", () -> String.valueOf(client.options.getFov().getValue()), () -> {
            int[] v = {70, 90, 100, 110};
            int cur = client.options.getFov().getValue(), nx = v[0];
            for (int x : v) if (x > cur) { nx = x; break; }
            client.options.getFov().setValue(nx);
        });
        cycle(3, "Max FPS", () -> {
            int f = client.options.getMaxFps().getValue();
            return f >= 260 ? "Unlimited" : String.valueOf(f);
        }, () -> {
            int[] v = {60, 120, 144, 240, 260};
            int cur = client.options.getMaxFps().getValue(), nx = v[0];
            for (int x : v) if (x > cur) { nx = x; break; }
            client.options.getMaxFps().setValue(nx);
        });
        cycle(3, "FOV Effects", () -> pct(client.options.getFovEffectScale().getValue()), () -> {
            double cur = client.options.getFovEffectScale().getValue();
            client.options.getFovEffectScale().setValue(cur > 0.75 ? 0.5 : cur > 0.25 ? 0.0 : 1.0);
        });
        items.add(new Item(3, () -> "View Bobbing", () -> client != null && client.options.getBobView().getValue(),
                () -> client.options.getBobView().setValue(!client.options.getBobView().getValue())));
        items.add(new Item(3, () -> "VSync", () -> client != null && client.options.getEnableVsync().getValue(),
                () -> client.options.getEnableVsync().setValue(!client.options.getEnableVsync().getValue())));
        items.add(new Item(3, () -> "Entity Shadows", () -> client != null && client.options.getEntityShadows().getValue(),
                () -> client.options.getEntityShadows().setValue(!client.options.getEntityShadows().getValue())));

        // ---- Mods
        for (HudModule m : HudModules.ALL) {
            toggle(2, m.name, m::enabled, v -> m.cfg().enabled = v);
        }

        // ---- Client
        cycle(4, "Toggle All Mods", () -> "", () -> {
            boolean any = false;
            for (HudModule m : HudModules.ALL) any |= m.enabled();
            for (HudModule m : HudModules.ALL) m.cfg().enabled = !any;
            say(any ? "All modules off" : "All modules on");
        });
        cycle(4, "Reset Positions", () -> "", () -> {
            for (HudModule m : HudModules.ALL) m.resetPos();
            say("Positions reset");
        });
        for (int n = 1; n <= 3; n++) {
            final int slot = n;
            cycle(4, "Save Profile " + n, () -> "", () -> say(Config.saveProfile(slot) ? "Saved profile " + slot : "Could not save"));
            cycle(4, "Load Profile " + n, () -> "", () -> say(Config.loadProfile(slot) ? "Loaded profile " + slot : "Profile " + slot + " is empty"));
        }
    }

    private static String pct(double v) { return Math.round(v * 100) + "%"; }

    private static void say(String s) {
        toast = s;
        toastUntil = Util.getMeasuringTimeMs() + 2500;
    }

    private void toggle(int t, String name, BooleanSupplier get, Consumer<Boolean> set) {
        items.add(new Item(t, () -> name, get, () -> set.accept(!get.getAsBoolean())));
    }

    private void cycle(int t, String name, Supplier<String> value, Runnable next) {
        items.add(new Item(t, () -> {
            String v = value.get();
            return v.isEmpty() ? name : name + ": " + v;
        }, null, next));
    }

    @Override
    protected void init() {
        wasDown = true;
        search = new TextFieldWidget(textRenderer, 0, 0, 100, 12, Text.literal(""));
        search.setPlaceholder(Text.literal("Search modules..."));
        search.setDrawsBackground(false);
        search.setMaxLength(24);
        search.setText(filter);
        search.setChangedListener(s -> filter = s.toLowerCase());
        addDrawableChild(search);
    }

    private boolean visible(Item it) {
        if (it.tab != tab) return false;
        return tab != 2 || filter.isEmpty() || it.label.get().toLowerCase().contains(filter);
    }

    private void layout() {
        rects.clear();
        int cols = Math.max(2, Math.min(4, (width - 2 * PAD - 8) / (BW + GAP)));
        pw = cols * BW + (cols - 1) * GAP + 2 * PAD;
        px = (width - pw) / 2;
        py = 6;
        tabW = (pw - 2 * PAD - 4 * GAP) / 5;
        int y = py + TITLE_H;
        if (collapsed) {
            ph = TITLE_H;
            return;
        }
        y += TAB_H + 4;
        if (tab == 2) y += 18;
        int col = 0;
        for (int i = 0; i < items.size(); i++) {
            if (!visible(items.get(i))) continue;
            rects.add(new int[]{px + PAD + col * (BW + GAP), y, BW, BH, i});
            if (++col == cols) { col = 0; y += BH + GAP; }
        }
        if (col != 0) y += BH + GAP;
        ph = y + PAD - py;
    }

    private static boolean inside(int mx, int my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private void centered(DrawContext ctx, String s, int x, int y, int w, int h, int color) {
        ctx.drawText(textRenderer, s, x + (w - textRenderer.getWidth(s)) / 2, y + (h - 8) / 2 + 1, color, true);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        layout();
        ctx.fill(0, 0, width, height, 0x66000000);

        HudRenderer.render(ctx, true);
        int sw = ctx.getScaledWindowWidth(), sh = ctx.getScaledWindowHeight();
        for (HudModule m : HudModules.ALL) {
            if (!m.enabled()) continue;
            Ui.border(ctx, m.px(sw) - 1, m.py(sh) - 1, m.width() + 2, m.height() + 2,
                    m == dragging ? 0xFFFFFFFF : 0x66FFFFFF);
        }

        Ui.rect(ctx, px, py, pw, ph, Theme.panelBg());
        Ui.accentLine(ctx, px, py, pw);
        ctx.drawText(textRenderer, "KURDISTAN CLIENT", px + PAD, py + 5, Theme.accent(), true);
        String chev = collapsed ? "+" : "-";
        ctx.drawText(textRenderer, chev, px + pw - PAD - textRenderer.getWidth(chev), py + 5, 0xFFB0B0C0, true);

        boolean showSearch = !collapsed && tab == 2;
        search.visible = showSearch;
        if (!showSearch) search.setFocused(false);

        if (!collapsed) {
            for (int i = 0; i < TABS.length; i++) {
                int tx = px + PAD + i * (tabW + GAP), ty = py + TITLE_H + 1;
                boolean sel = i == tab;
                boolean hov = inside(mouseX, mouseY, tx, ty, tabW, TAB_H - 2);
                Ui.rect(ctx, tx, ty, tabW, TAB_H - 2, sel ? Theme.accentA(0xC0) : (hov ? 0x55FFFFFF : 0x2AFFFFFF));
                centered(ctx, TABS[i], tx, ty, tabW, TAB_H - 2, 0xFFFFFFFF);
            }
            if (showSearch) {
                int fx = px + PAD, fy = py + TITLE_H + TAB_H + 4, fw = pw - 2 * PAD;
                Ui.rect(ctx, fx, fy, fw, 14, 0x40FFFFFF);
                search.setPosition(fx + 5, fy + 3);
                search.setWidth(fw - 10);
                search.render(ctx, mouseX, mouseY, delta);
            }
            for (int[] r : rects) {
                Item it = items.get(r[4]);
                boolean hov = inside(mouseX, mouseY, r[0], r[1], r[2], r[3]);
                boolean on = it.on != null && it.on.getAsBoolean();
                int bg;
                if (it.on == null) bg = hov ? 0x66FFFFFF : 0x33FFFFFF;
                else if (on) bg = Theme.accentA(hov ? 0xE0 : 0xB0);
                else bg = hov ? 0x55FFFFFF : 0x2AFFFFFF;
                Ui.rect(ctx, r[0], r[1], r[2], r[3], bg);
                if (it.on != null) ctx.fill(r[0] + 5, r[1] + 6, r[0] + 9, r[1] + 10, on ? 0xFFFFFFFF : 0x55FFFFFF);
                int off = it.on != null ? 6 : 0;
                centered(ctx, it.label.get(), r[0] + off, r[1], r[2] - off, r[3],
                        on || it.on == null ? 0xFFFFFFFF : 0xFFB8B8C8);
            }
        }

        String hint = Util.getMeasuringTimeMs() < toastUntil ? toast : "Drag modules anywhere   |   ESC to save";
        ctx.drawText(textRenderer, hint, (width - textRenderer.getWidth(hint)) / 2, height - 12,
                Util.getMeasuringTimeMs() < toastUntil ? Theme.accent() : 0xFF9A9AAA, true);

        boolean down = GLFW.glfwGetMouseButton(client.getWindow().getHandle(), GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        if (down && !wasDown) {
            if (inside(mouseX, mouseY, px, py, pw, TITLE_H)) {
                collapsed = !collapsed;
            } else if (inside(mouseX, mouseY, px, py, pw, ph)) {
                if (!collapsed) {
                    for (int i = 0; i < TABS.length; i++) {
                        if (inside(mouseX, mouseY, px + PAD + i * (tabW + GAP), py + TITLE_H + 1, tabW, TAB_H - 2)) {
                            tab = i;
                            search.setFocused(false);
                        }
                    }
                    for (int[] r : rects) {
                        if (inside(mouseX, mouseY, r[0], r[1], r[2], r[3])) {
                            items.get(r[4]).action.run();
                            Config.save();
                        }
                    }
                }
            } else {
                for (int i = HudModules.ALL.size() - 1; i >= 0; i--) {
                    HudModule m = HudModules.ALL.get(i);
                    if (!m.enabled()) continue;
                    int x = m.px(sw), y = m.py(sh);
                    if (inside(mouseX, mouseY, x, y, m.width(), m.height())) {
                        dragging = m;
                        offX = mouseX - x;
                        offY = mouseY - y;
                        break;
                    }
                }
            }
        }
        if (!down && dragging != null) {
            Config.save();
            dragging = null;
        }
        if (dragging != null) {
            dragging.cfg().x = Math.max(0, Math.min(mouseX - offX, sw - dragging.width()));
            dragging.cfg().y = Math.max(0, Math.min(mouseY - offY, sh - dragging.height()));
        }
        wasDown = down;
    }

    @Override
    public void removed() {
        Config.save();
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
