package dev.kurdistan.client;

import dev.kurdistan.client.hud.HudModule;
import dev.kurdistan.client.hud.HudModules;
import dev.kurdistan.client.hud.HudRenderer;
import dev.kurdistan.client.hud.Ui;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.Element;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

public class EditorScreen extends Screen {
    private HudModule dragging;
    private int offX, offY;
    private boolean wasDown;
    private int index;

    public EditorScreen() {
        super(Text.literal("Kurdistan Client"));
    }

    @Override
    protected void init() {
        index = 0;
        wasDown = true; // ignore the click that might have opened the screen
        toggle("Freelook", () -> Config.I.freelook, v -> Config.I.freelook = v);
        toggle("Fullbright", () -> Config.I.fullbright, v -> Config.I.fullbright = v);
        toggle("Zoom", () -> Config.I.zoom, v -> Config.I.zoom = v);
        toggle("Toggle Sprint", () -> Config.I.toggleSprint, v -> Config.I.toggleSprint = v);
        for (HudModule m : HudModules.ALL) {
            toggle(m.name, m::enabled, v -> m.cfg().enabled = v);
        }
    }

    private void toggle(String name, BooleanSupplier get, Consumer<Boolean> set) {
        int bw = 100, bh = 18, gap = 4, cols = width >= 330 ? 3 : 2;
        int x = width / 2 - (cols * bw + (cols - 1) * gap) / 2 + (index % cols) * (bw + gap);
        int y = 28 + (index / cols) * (bh + gap);
        index++;
        addDrawableChild(ButtonWidget.builder(label(name, get.getAsBoolean()), b -> {
            set.accept(!get.getAsBoolean());
            Config.save();
            b.setMessage(label(name, get.getAsBoolean()));
        }).dimensions(x, y, bw, bh).build());
    }

    private static Text label(String name, boolean on) {
        return Text.literal(name + ": " + (on ? "ON" : "OFF"));
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        ctx.drawCenteredTextWithShadow(textRenderer, "KURDISTAN CLIENT  -  drag modules anywhere, ESC to save", width / 2, 10, 0xFFFFFFFF);

        HudRenderer.render(ctx, true);

        int sw = ctx.getScaledWindowWidth(), sh = ctx.getScaledWindowHeight();
        for (HudModule m : HudModules.ALL) {
            if (!m.enabled()) continue;
            Ui.border(ctx, m.px(sw) - 1, m.py(sh) - 1, m.width() + 2, m.height() + 2,
                    m == dragging ? 0xFFFFFFFF : 0x66FFFFFF);
        }

        boolean down = GLFW.glfwGetMouseButton(client.getWindow().getHandle(), GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        if (down && !wasDown) {
            boolean overButton = false;
            for (Element e : children()) if (e.isMouseOver(mouseX, mouseY)) overButton = true;
            if (!overButton) {
                for (int i = HudModules.ALL.size() - 1; i >= 0; i--) {
                    HudModule m = HudModules.ALL.get(i);
                    if (!m.enabled()) continue;
                    int x = m.px(sw), y = m.py(sh);
                    if (mouseX >= x && mouseX <= x + m.width() && mouseY >= y && mouseY <= y + m.height()) {
                        dragging = m;
                        offX = mouseX - x;
                        offY = mouseY - y;
                        break;
                    }
                }
            }
        }
        if (!down && dragging != null) {
            Config.save();
            dragging = null;
        }
        if (dragging != null) {
            dragging.cfg().x = Math.max(0, Math.min(mouseX - offX, sw - dragging.width()));
            dragging.cfg().y = Math.max(0, Math.min(mouseY - offY, sh - dragging.height()));
        }
        wasDown = down;
    }

    @Override
    public void removed() {
        Config.save();
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
