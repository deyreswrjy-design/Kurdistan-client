package dev.kurdistan.client.hud;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

public final class Ui {
    public static TextRenderer tr() { return MinecraftClient.getInstance().textRenderer; }

    public static void panel(DrawContext c, int x, int y, int w, int h) {
        c.fill(x, y, x + w, y + h, 0x99101014);
        int t = w / 3;
        c.fill(x, y, x + t, y + 1, 0xFFED2024);
        c.fill(x + t, y, x + 2 * t, y + 1, 0xFFFFFFFF);
        c.fill(x + 2 * t, y, x + w, y + 1, 0xFF278E43);
    }

    public static void border(DrawContext c, int x, int y, int w, int h, int color) {
        c.fill(x, y, x + w, y + 1, color);
        c.fill(x, y + h - 1, x + w, y + h, color);
        c.fill(x, y, x + 1, y + h, color);
        c.fill(x + w - 1, y, x + w, y + h, color);
    }

    public static void text(DrawContext c, String s, int x, int y, int color) {
        c.drawText(tr(), s, x, y, color, true);
    }
}
