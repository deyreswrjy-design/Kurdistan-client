package dev.kurdistan.client.hud;

import dev.kurdistan.client.Config;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

public final class Ui {
    /** Per-module style overrides, set by HudRenderer while a module draws. */
    public static int ovText = 0, ovBg = 0, ovOpacity = -1;

    public static int defText() { return ovText != 0 ? ovText : Theme.text(); }

    public static int bgColor() { return ovOpacity >= 0 ? Theme.bgWithOpacity(ovOpacity) : Theme.bg(); }

    public static TextRenderer tr() { return MinecraftClient.getInstance().textRenderer; }

    /** Filled rectangle, optionally with rounded corners (no overlapping fills, so alpha stays even). */
    public static void rect(DrawContext c, int x, int y, int w, int h, int color) {
        if (!Config.I.rounded || w < 8 || h < 8) {
            c.fill(x, y, x + w, y + h, color);
            return;
        }
        c.fill(x + 2, y, x + w - 2, y + 1, color);
        c.fill(x + 1, y + 1, x + w - 1, y + 2, color);
        c.fill(x, y + 2, x + w, y + h - 2, color);
        c.fill(x + 1, y + h - 2, x + w - 1, y + h - 1, color);
        c.fill(x + 2, y + h - 1, x + w - 2, y + h, color);
    }

    public static void accentLine(DrawContext c, int x, int y, int w) {
        int x0 = x + 2, x1 = x + w - 2, len = x1 - x0;
        if (Theme.isKurdish()) {
            int t = len / 3;
            c.fill(x0, y, x0 + t, y + 1, 0xFFED2024);
            c.fill(x0 + t, y, x0 + 2 * t, y + 1, 0xFFFFFFFF);
            c.fill(x0 + 2 * t, y, x1, y + 1, 0xFF278E43);
        } else {
            c.fill(x0, y, x1, y + 1, Theme.accent());
        }
    }

    public static void panel(DrawContext c, int x, int y, int w, int h) {
        if (ovBg == 1) return;
        rect(c, x, y, w, h, bgColor());
        accentLine(c, x, y, w);
    }

    public static void border(DrawContext c, int x, int y, int w, int h, int color) {
        c.fill(x, y, x + w, y + 1, color);
        c.fill(x, y + h - 1, x + w, y + h, color);
        c.fill(x, y + 1, x + 1, y + h - 1, color);
        c.fill(x + w - 1, y + 1, x + w, y + h - 1, color);
    }

    public static void text(DrawContext c, String s, int x, int y) {
        c.drawText(tr(), s, x, y, defText(), true);
    }

    public static void text(DrawContext c, String s, int x, int y, int color) {
        c.drawText(tr(), s, x, y, color, true);
    }
}
