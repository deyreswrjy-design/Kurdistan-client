package dev.kurdistan.client.hud;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.option.GameOptions;
import net.minecraft.util.Util;
import net.minecraft.util.math.MathHelper;

import java.util.ArrayDeque;
import java.util.List;
import java.util.function.Supplier;

public final class HudModules {
    public static final List<HudModule> ALL = List.of(
            new TextModule("fps", "FPS", 4, 4, true,
                    () -> "FPS: " + MinecraftClient.getInstance().getCurrentFps()),
            new TextModule("cps", "CPS", 4, 22, true,
                    HudModules::cpsText),
            new TextModule("ping", "Ping", 4, 40, false, HudModules::pingText),
            new TextModule("coords", "Coords", 4, 58, false, HudModules::coordsText),
            new Keystrokes(),
            new MouseStrokes()
    );

    // ---- per-frame trackers ----
    private static final ArrayDeque<Long> left = new ArrayDeque<>(), right = new ArrayDeque<>();
    private static boolean prevL, prevR;
    private static final ArrayDeque<float[]> trail = new ArrayDeque<>();
    private static float lastYaw, lastPitch, sx, sy;
    private static boolean mouseInit;

    public static void update() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        GameOptions o = mc.options;

        long now = Util.getMeasuringTimeMs();
        boolean l = o.attackKey.isPressed(), r = o.useKey.isPressed();
        if (l && !prevL) left.add(now);
        if (r && !prevR) right.add(now);
        prevL = l;
        prevR = r;
        while (!left.isEmpty() && now - left.peekFirst() > 1000) left.pollFirst();
        while (!right.isEmpty() && now - right.peekFirst() > 1000) right.pollFirst();

        float yaw = dev.kurdistan.client.Features.flActive ? dev.kurdistan.client.Features.flYaw : mc.player.getYaw();
        float pitch = dev.kurdistan.client.Features.flActive ? dev.kurdistan.client.Features.flPitch : mc.player.getPitch();
        if (!mouseInit) { lastYaw = yaw; lastPitch = pitch; mouseInit = true; }
        float dx = MathHelper.wrapDegrees(yaw - lastYaw), dy = pitch - lastPitch;
        lastYaw = yaw;
        lastPitch = pitch;
        sx = MathHelper.clamp(sx * 0.85f + dx * 0.6f, -22f, 22f);
        sy = MathHelper.clamp(sy * 0.85f + dy * 0.6f, -22f, 22f);
        trail.addFirst(new float[]{sx, sy});
        while (trail.size() > 22) trail.removeLast();
    }

    private static String cpsText() {
        return "CPS: " + left.size() + " | " + right.size();
    }

    private static String pingText() {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayNetworkHandler h = mc.getNetworkHandler();
        if (h == null || mc.player == null) return "Ping: -";
        PlayerListEntry e = h.getPlayerListEntry(mc.player.getUuid());
        return "Ping: " + (e == null ? 0 : e.getLatency()) + " ms";
    }

    private static String coordsText() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return "XYZ: -";
        return "XYZ: " + mc.player.getBlockX() + " / " + mc.player.getBlockY() + " / " + mc.player.getBlockZ();
    }

    // ---- modules ----
    static final class TextModule extends HudModule {
        private final Supplier<String> text;

        TextModule(String id, String name, int x, int y, boolean en, Supplier<String> text) {
            super(id, name, x, y, en);
            this.text = text;
        }

        @Override public int width() { return Ui.tr().getWidth(text.get()) + 10; }
        @Override public int height() { return 15; }

        @Override
        public void draw(DrawContext c, int x, int y) {
            Ui.panel(c, x, y, width(), height());
            Ui.text(c, text.get(), x + 5, y + 4, 0xFFFFFFFF);
        }
    }

    static final class Keystrokes extends HudModule {
        private static final int S = 20, G = 2;

        Keystrokes() { super("keystrokes", "Keystrokes", 4, 80, true); }

        @Override public int width() { return 3 * S + 2 * G; }
        @Override public int height() { return 3 * (S + G) + 12; }

        @Override
        public void draw(DrawContext c, int x, int y) {
            GameOptions o = MinecraftClient.getInstance().options;
            key(c, x + S + G, y, S, S, "W", o.forwardKey.isPressed());
            key(c, x, y + S + G, S, S, "A", o.leftKey.isPressed());
            key(c, x + S + G, y + S + G, S, S, "S", o.backKey.isPressed());
            key(c, x + 2 * (S + G), y + S + G, S, S, "D", o.rightKey.isPressed());
            int half = (width() - G) / 2;
            key(c, x, y + 2 * (S + G), half, S, "LMB", o.attackKey.isPressed());
            key(c, x + half + G, y + 2 * (S + G), width() - half - G, S, "RMB", o.useKey.isPressed());
            key(c, x, y + 3 * (S + G), width(), 12, "", o.jumpKey.isPressed());
            int lc = o.jumpKey.isPressed() ? 0xFF111111 : 0xFFFFFFFF;
            c.fill(x + 18, y + 3 * (S + G) + 5, x + width() - 18, y + 3 * (S + G) + 7, lc);
        }

        private static void key(DrawContext c, int x, int y, int w, int h, String label, boolean down) {
            c.fill(x, y, x + w, y + h, down ? 0xCCFFFFFF : 0x99101014);
            if (!label.isEmpty()) {
                int tw = Ui.tr().getWidth(label);
                c.drawText(Ui.tr(), label, x + (w - tw) / 2, y + (h - 8) / 2 + 1,
                        down ? 0xFF111111 : 0xFFFFFFFF, !down);
            }
        }
    }

    static final class MouseStrokes extends HudModule {
        MouseStrokes() { super("mousestrokes", "Mouse Strokes", 80, 80, true); }

        @Override public int width() { return 54; }
        @Override public int height() { return 54; }

        @Override
        public void draw(DrawContext c, int x, int y) {
            Ui.panel(c, x, y, width(), height());
            int cx = x + width() / 2, cy = y + height() / 2 + 1;
            c.fill(cx, y + 4, cx + 1, y + height() - 4, 0x33FFFFFF);
            c.fill(x + 4, cy, x + width() - 4, cy + 1, 0x33FFFFFF);
            int i = 0, n = trail.size();
            for (float[] p : trail) {
                int a = (int) (255f * (1f - (float) i / n));
                int col = (a << 24) | 0xFFFFFF;
                int r = i == 0 ? 2 : 1;
                int px = cx + Math.round(p[0]), py = cy + Math.round(p[1]);
                c.fill(px - r, py - r, px + r, py + r, col);
                i++;
            }
        }
    }
}
