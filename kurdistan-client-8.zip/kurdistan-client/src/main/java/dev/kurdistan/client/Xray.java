package dev.kurdistan.client;

import dev.kurdistan.client.mixin.MinecraftClientAccessor;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.registry.Registries;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/** Xray: hides normal blocks and shows chosen ores. Works in singleplayer only. */
public final class Xray {
    public static volatile boolean active;

    public static final String[] KEYS = {"coal", "iron", "copper", "gold", "redstone", "lapis", "diamond", "emerald", "quartz", "debris", "chest", "spawner"};
    public static final String[] NAMES = {"Coal", "Iron", "Copper", "Gold", "Redstone", "Lapis", "Diamond", "Emerald", "Quartz", "Ancient Debris", "Chests", "Spawners"};

    private static final Map<Block, Boolean> CACHE = new ConcurrentHashMap<>();

    public static boolean on(String key) {
        Boolean b = Config.I.xrayBlocks.get(key);
        return b == null ? !key.equals("coal") : b;
    }

    public static void set(String key, boolean v) {
        Config.I.xrayBlocks.put(key, v);
    }

    /** Called from the block renderer threads. */
    public static boolean visible(BlockState state) {
        return CACHE.computeIfAbsent(state.getBlock(), Xray::compute);
    }

    private static boolean compute(Block block) {
        String p = Registries.BLOCK.getId(block).getPath();
        boolean ore = p.endsWith("_ore") || p.equals("ancient_debris");
        for (String k : KEYS) {
            if (!on(k)) continue;
            switch (k) {
                case "chest" -> { if (p.contains("chest")) return true; }
                case "spawner" -> { if (p.contains("spawner")) return true; }
                case "debris" -> { if (p.equals("ancient_debris")) return true; }
                default -> { if (ore && p.contains(k)) return true; }
            }
        }
        return false;
    }

    /** Re-evaluates whether xray should be on and rebuilds the world meshes. */
    public static void refresh() {
        MinecraftClient mc = MinecraftClient.getInstance();
        CACHE.clear();
        active = Config.I.xray && mc.world != null && mc.isInSingleplayer();
        culling(mc, !active);
        if (mc.world != null && mc.worldRenderer != null) mc.worldRenderer.reload();
    }

    public static void culling(MinecraftClient mc, boolean enabled) {
        try {
            ((MinecraftClientAccessor) (Object) mc).kurdistan$setCulling(enabled);
        } catch (Throwable ignored) {
        }
    }
}
