package dev.kurdistan.client.mixin;

import dev.kurdistan.client.Config;
import dev.kurdistan.client.KurdistanTitleScreen;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.TitleScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(MinecraftClient.class)
public class MinecraftClientMixin {
    @ModifyVariable(method = "setScreen", at = @At("HEAD"), argsOnly = true, require = 0)
    private Screen kurdistan$title(Screen screen) {
        if (screen instanceof TitleScreen && Config.I.customMenu) return new KurdistanTitleScreen();
        return screen;
    }
}
