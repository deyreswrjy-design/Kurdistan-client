package dev.kurdistan.client.hud;

import dev.kurdistan.client.Config;
import net.minecraft.client.gui.DrawContext;

public abstract class HudModule {
    public final String id, name;
    private final int dx, dy;
    private final boolean den;

    protected HudModule(String id, String name, int x, int y, boolean enabled) {
        this.id = id;
        this.name = name;
        this.dx = x;
        this.dy = y;
        this.den = enabled;
        Config.I.hud(id, x, y, enabled);
    }

    public Config.Hud cfg() { return Config.I.hud(id, dx, dy, den); }
    public boolean enabled() { return cfg().enabled; }
    public void resetPos() { cfg().x = dx; cfg().y = dy; }

    public abstract int width();
    public abstract int height();
    public abstract void draw(DrawContext c, int x, int y);

    public int px(int sw) { return Math.max(0, Math.min(cfg().x, sw - width())); }
    public int py(int sh) { return Math.max(0, Math.min(cfg().y, sh - height())); }
}
