package dev.kurdistan.client.mixin;

import dev.kurdistan.client.Config;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(World.class)
public class WorldMixin {
    @Inject(method = {"getRainGradient", "getThunderGradient"}, at = @At("HEAD"), cancellable = true, require = 0)
    private void kurdistan$noWeather(float delta, CallbackInfoReturnable<Float> cir) {
        if (Config.I.noWeather && (Object) this instanceof ClientWorld) cir.setReturnValue(0f);
    }
}
