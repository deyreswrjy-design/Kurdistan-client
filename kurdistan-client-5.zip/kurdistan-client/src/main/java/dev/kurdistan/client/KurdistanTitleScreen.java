package dev.kurdistan.client;

import dev.kurdistan.client.hud.Theme;
import dev.kurdistan.client.hud.Ui;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.text.Text;
import net.minecraft.util.Util;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/** Fully custom main menu (replaces the vanilla title screen). */
public class KurdistanTitleScreen extends Screen {
    private record Btn(String label, Runnable action) {}

    private final List<Btn> btns = new ArrayList<>();
    private boolean wasDown = true;

    public KurdistanTitleScreen() {
        super(Text.literal("Kurdistan Client"));
    }

    @Override
    protected void init() {
        wasDown = true;
        btns.clear();
        btns.add(new Btn("Singleplayer", () -> client.setScreen(new SelectWorldScreen(this))));
        btns.add(new Btn("Multiplayer", () -> client.setScreen(new MultiplayerScreen(this))));
        btns.add(new Btn("Options", () -> client.setScreen(new OptionsScreen(this, client.options))));
        btns.add(new Btn("Quit Game", () -> client.scheduleStop()));
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        int w = width, h = height;
        long t = Util.getMeasuringTimeMs();

        ctx.fillGradient(0, 0, w, h, 0xFF090B14, 0xFF14101F);
        ctx.fillGradient(0, h / 2, w, h, Theme.accentA(0x00), Theme.accentA(0x28));

        // floating particles
        for (int i = 0; i < 48; i++) {
            int x = (i * 97 + 31) % Math.max(1, w);
            double speed = 0.012 + (i % 5) * 0.006;
            int y = h - (int) ((t * speed + i * 53) % h);
            int a = 40 + (i % 4) * 25;
            ctx.fill(x, y, x + 2, y + 2, Theme.withAlpha(0xFFFFFF, a));
        }

        int cx = w / 2;
        int top = Math.max(12, h / 2 - 96);
        SplashBrand.scaled(ctx, textRenderer, "KURDISTAN", cx, top, 4f, 0xFFFFFFFF);
        SplashBrand.scaled(ctx, textRenderer, "C L I E N T", cx, top + 38, 1.6f, Theme.accent());
        int lx = cx - 60, ly = top + 56;
        ctx.fill(lx, ly, lx + 40, ly + 2, 0xFFED2024);
        ctx.fill(lx + 40, ly, lx + 80, ly + 2, 0xFFFFFFFF);
        ctx.fill(lx + 80, ly, lx + 120, ly + 2, 0xFF278E43);

        int bw = 160, bh = 20, gap = 6;
        int by = ly + 18;
        boolean down = GLFW.glfwGetMouseButton(client.getWindow().getHandle(), GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        for (int i = 0; i < btns.size(); i++) {
            int x = cx - bw / 2, y = by + i * (bh + gap);
            boolean hov = mouseX >= x && mouseX < x + bw && mouseY >= y && mouseY < y + bh;
            Ui.rect(ctx, x, y, bw, bh, hov ? Theme.accentA(0xCC) : 0x40FFFFFF);
            if (hov) Ui.accentLine(ctx, x, y, bw);
            String label = btns.get(i).label;
            ctx.drawText(textRenderer, label, x + (bw - textRenderer.getWidth(label)) / 2, y + 6, 0xFFFFFFFF, true);
            if (hov && down && !wasDown) client.send(btns.get(i).action);
        }
        wasDown = down;

        ctx.drawText(textRenderer, "Kurdistan Client  -  by Kurdistan Developer", 6, h - 12, 0xFF9A9AAA, true);
        String v = "Minecraft 1.21.11";
        ctx.drawText(textRenderer, v, w - textRenderer.getWidth(v) - 6, h - 12, 0xFF9A9AAA, true);
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return false;
    }
}
