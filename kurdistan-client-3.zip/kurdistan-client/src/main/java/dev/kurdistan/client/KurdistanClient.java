package dev.kurdistan.client;

import dev.kurdistan.client.hud.HudRenderer;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;

public class KurdistanClient implements ClientModInitializer {
    public static final String ID = "kurdistan";

    @Override
    public void onInitializeClient() {
        Config.load();
        Keys.register();
        HudRenderer.register();
        ClientTickEvents.END_CLIENT_TICK.register(Features::tick);
        ClientLifecycleEvents.CLIENT_STOPPING.register(Features::shutdown);
    }
}
