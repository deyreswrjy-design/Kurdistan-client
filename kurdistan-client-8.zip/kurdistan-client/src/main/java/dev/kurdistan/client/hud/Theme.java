package dev.kurdistan.client.hud;

import dev.kurdistan.client.Config;
import net.minecraft.util.Util;
import net.minecraft.util.math.MathHelper;

public final class Theme {
    public static final String[] ACCENT_NAMES = {"Kurdish", "Ocean", "Purple", "Crimson", "Emerald", "Gold", "Pink", "Rainbow"};
    private static final int[] ACCENT = {0xFF278E43, 0xFF2D9CFF, 0xFF9B5CFF, 0xFFE0243A, 0xFF2ECC71, 0xFFF5C518, 0xFFFF5CAA, 0};

    public static final String[] BG_NAMES = {"Dark", "Black", "Navy", "Plum", "Forest"};
    private static final int[] BG = {0x101014, 0x000000, 0x0B1226, 0x1A0F26, 0x0C1A12};

    public static final String[] TEXT_NAMES = {"White", "Accent", "Cyan", "Yellow", "Gray"};
    private static final int[] TEXT = {0xFFFFFFFF, 0, 0xFF7FE8FF, 0xFFFFE066, 0xFFC8C8D0};

    public static final String[] PAL_NAMES = {"Theme", "White", "Accent", "Cyan", "Yellow", "Red", "Green", "Pink", "Orange"};

    public static int palette(int i) {
        switch (Math.floorMod(i, PAL_NAMES.length)) {
            case 0: return 0;
            case 1: return 0xFFFFFFFF;
            case 2: return accent();
            case 3: return 0xFF7FE8FF;
            case 4: return 0xFFFFE066;
            case 5: return 0xFFFF5555;
            case 6: return 0xFF55FF77;
            case 7: return 0xFFFF7EC8;
            default: return 0xFFFFA64D;
        }
    }

    public static int bgWithOpacity(int pct) {
        return withAlpha(BG[idx(Config.I.bgColor, BG.length)], MathHelper.clamp(pct, 0, 100) * 255 / 100);
    }

    private static int idx(int v, int len) { return Math.floorMod(v, len); }

    public static boolean isKurdish() { return idx(Config.I.accent, ACCENT.length) == 0; }

    public static int accent() {
        int i = idx(Config.I.accent, ACCENT.length);
        if (i == ACCENT.length - 1) {
            float h = (Util.getMeasuringTimeMs() % 4000L) / 4000f;
            return 0xFF000000 | MathHelper.hsvToRgb(h, 0.65f, 1f);
        }
        return ACCENT[i];
    }

    public static int withAlpha(int argb, int alpha) { return (alpha << 24) | (argb & 0xFFFFFF); }
    public static int accentA(int alpha) { return withAlpha(accent(), alpha); }

    public static int bg() {
        int a = MathHelper.clamp(Config.I.bgOpacity, 0, 100) * 255 / 100;
        return withAlpha(BG[idx(Config.I.bgColor, BG.length)], a);
    }

    public static int panelBg() { return withAlpha(BG[idx(Config.I.bgColor, BG.length)], 0xE8); }

    public static int text() {
        int i = idx(Config.I.textColor, TEXT.length);
        return i == 1 ? accent() : TEXT[i];
    }
}
