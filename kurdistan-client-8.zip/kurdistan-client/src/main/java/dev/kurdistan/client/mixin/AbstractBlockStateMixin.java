package dev.kurdistan.client.mixin;

import dev.kurdistan.client.Xray;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.BlockRenderType;
import net.minecraft.block.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(AbstractBlock.AbstractBlockState.class)
public abstract class AbstractBlockStateMixin {
    @Inject(method = "getRenderType", at = @At("HEAD"), cancellable = true, require = 0)
    private void kurdistan$xrayHide(CallbackInfoReturnable<BlockRenderType> cir) {
        if (Xray.active && !Xray.visible((BlockState) (Object) this)) {
            cir.setReturnValue(BlockRenderType.INVISIBLE);
        }
    }

    @Inject(method = "isOpaque", at = @At("HEAD"), cancellable = true, require = 0)
    private void kurdistan$xrayOpaque(CallbackInfoReturnable<Boolean> cir) {
        if (Xray.active) cir.setReturnValue(false);
    }
}
