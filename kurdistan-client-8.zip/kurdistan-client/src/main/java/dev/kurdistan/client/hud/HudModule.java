package dev.kurdistan.client.hud;

import dev.kurdistan.client.Config;
import net.minecraft.client.gui.DrawContext;

public abstract class HudModule {
    /** A module-specific setting that cycles through named values. */
    public record Opt(String key, String label, String[] values, int def) {}

    private static final Opt[] NONE = new Opt[0];

    public final String id, name;
    private final int dx, dy;
    private final boolean den;

    protected HudModule(String id, String name, int x, int y, boolean enabled) {
        this.id = id;
        this.name = name;
        this.dx = x;
        this.dy = y;
        this.den = enabled;
        Config.I.hud(id, x, y, enabled);
    }

    public Config.Hud cfg() { return Config.I.hud(id, dx, dy, den); }
    public boolean enabled() { return cfg().enabled; }
    public void resetPos() { cfg().x = dx; cfg().y = dy; }

    public Opt[] options() { return NONE; }
    public boolean hasLabel() { return false; }

    public int opt(String key) {
        for (Opt o : options()) {
            if (o.key().equals(key)) return Math.floorMod(cfg().opt.getOrDefault(key, o.def()), o.values().length);
        }
        return 0;
    }

    public float scale() { return Math.max(0.5f, cfg().scale / 100f); }
    public int ew() { return Math.round(width() * scale()); }
    public int eh() { return Math.round(height() * scale()); }

    public abstract int width();
    public abstract int height();
    public abstract void draw(DrawContext c, int x, int y);

    public int px(int sw) { return Math.max(0, Math.min(cfg().x, sw - ew())); }
    public int py(int sh) { return Math.max(0, Math.min(cfg().y, sh - eh())); }
}
