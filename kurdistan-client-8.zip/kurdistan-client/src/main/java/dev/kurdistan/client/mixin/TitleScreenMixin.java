package dev.kurdistan.client.mixin;

import dev.kurdistan.client.Config;
import dev.kurdistan.client.MainMenu;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.TitleScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(TitleScreen.class)
public class TitleScreenMixin {
    @Inject(method = "render", at = @At("TAIL"), require = 0)
    private void kurdistan$menu(DrawContext context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        if (Config.I.customMenu) MainMenu.draw(context);
    }
}
