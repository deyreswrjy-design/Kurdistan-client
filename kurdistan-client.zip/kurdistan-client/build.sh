#!/usr/bin/env bash
# Needs JDK 21. Installs the Gradle wrapper on first run, then builds.
set -e
if [ ! -f gradlew ]; then
  command -v gradle >/dev/null || { echo "Install Gradle 9.x first: https://gradle.org/install"; exit 1; }
  gradle wrapper --gradle-version 9.2.0
fi
chmod +x gradlew
./gradlew build
echo "Your jar is in build/libs/kurdistan-client-1.0.0.jar"
