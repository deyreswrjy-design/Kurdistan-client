package dev.kurdistan.client;

import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public final class Keys {
    public static KeyBinding FREELOOK, FULLBRIGHT, ZOOM, MENU;

    public static void register() {
        KeyBinding.Category cat = KeyBinding.Category.create(Identifier.of(KurdistanClient.ID, "main"));
        FREELOOK = reg("key.kurdistan.freelook", GLFW.GLFW_KEY_LEFT_ALT, cat);
        FULLBRIGHT = reg("key.kurdistan.fullbright", GLFW.GLFW_KEY_G, cat);
        ZOOM = reg("key.kurdistan.zoom", GLFW.GLFW_KEY_C, cat);
        MENU = reg("key.kurdistan.menu", GLFW.GLFW_KEY_RIGHT_SHIFT, cat);
    }

    private static KeyBinding reg(String name, int key, KeyBinding.Category cat) {
        return KeyBindingHelper.registerKeyBinding(new KeyBinding(name, InputUtil.Type.KEYSYM, key, cat));
    }
}
