package dev.kurdistan.client.mixin;

import dev.kurdistan.client.Config;
import net.minecraft.client.render.entity.ItemEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import org.joml.Quaternionf;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/** Item Physics (experimental): dropped items lie flat on the ground instead of spinning. */
@Mixin(ItemEntityRenderer.class)
public class ItemEntityRendererMixin {
    @Redirect(method = {"render", "submit", "renderStack"},
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/util/math/MatrixStack;multiply(Lorg/joml/Quaternionf;)V"),
            require = 0)
    private void kurdistan$flat(MatrixStack stack, Quaternionf q) {
        if (Config.I.itemPhysics) {
            stack.multiply(new Quaternionf().rotationX((float) (Math.PI / 2.0)));
        } else {
            stack.multiply(q);
        }
    }
}
