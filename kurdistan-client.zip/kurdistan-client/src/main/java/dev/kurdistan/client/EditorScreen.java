package dev.kurdistan.client;

import dev.kurdistan.client.hud.HudModule;
import dev.kurdistan.client.hud.HudModules;
import dev.kurdistan.client.hud.HudRenderer;
import dev.kurdistan.client.hud.Theme;
import dev.kurdistan.client.hud.Ui;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.Supplier;

/** Custom-drawn menu: tabs, theme options, module toggles, and drag-and-drop HUD editing. */
public class EditorScreen extends Screen {
    private static final int BW = 96, BH = 16, GAP = 3, PAD = 6, TITLE_H = 16, TAB_H = 16;
    private static final String[] TABS = {"Features", "Theme", "Modules"};
    private static int tab;
    private static boolean collapsed;

    private record Item(int tab, Supplier<String> label, BooleanSupplier on, Runnable action) {}

    private final List<Item> items = new ArrayList<>();
    private final List<int[]> rects = new ArrayList<>(); // x, y, w, h, itemIndex
    private int px, py, pw, ph, tabW;

    private HudModule dragging;
    private int offX, offY;
    private boolean wasDown = true;

    public EditorScreen() {
        super(Text.literal("Kurdistan Client"));
        toggle(0, "Freelook", () -> Config.I.freelook, v -> Config.I.freelook = v);
        toggle(0, "Fullbright", () -> Config.I.fullbright, v -> Config.I.fullbright = v);
        toggle(0, "Zoom", () -> Config.I.zoom, v -> Config.I.zoom = v);
        toggle(0, "Toggle Sprint", () -> Config.I.toggleSprint, v -> Config.I.toggleSprint = v);

        cycle("Accent", () -> Theme.ACCENT_NAMES[Math.floorMod(Config.I.accent, Theme.ACCENT_NAMES.length)],
                () -> Config.I.accent = (Config.I.accent + 1) % Theme.ACCENT_NAMES.length);
        cycle("Background", () -> Theme.BG_NAMES[Math.floorMod(Config.I.bgColor, Theme.BG_NAMES.length)],
                () -> Config.I.bgColor = (Config.I.bgColor + 1) % Theme.BG_NAMES.length);
        cycle("BG Opacity", () -> Config.I.bgOpacity + "%",
                () -> Config.I.bgOpacity = ((Config.I.bgOpacity / 20 + 1) % 6) * 20);
        cycle("Text", () -> Theme.TEXT_NAMES[Math.floorMod(Config.I.textColor, Theme.TEXT_NAMES.length)],
                () -> Config.I.textColor = (Config.I.textColor + 1) % Theme.TEXT_NAMES.length);
        cycle("Corners", () -> Config.I.rounded ? "Rounded" : "Square",
                () -> Config.I.rounded = !Config.I.rounded);

        for (HudModule m : HudModules.ALL) {
            toggle(2, m.name, m::enabled, v -> m.cfg().enabled = v);
        }
    }

    private void toggle(int t, String name, BooleanSupplier get, Consumer<Boolean> set) {
        items.add(new Item(t, () -> name, get, () -> set.accept(!get.getAsBoolean())));
    }

    private void cycle(String name, Supplier<String> value, Runnable next) {
        items.add(new Item(1, () -> name + ": " + value.get(), null, next));
    }

    private void layout() {
        rects.clear();
        int cols = Math.max(2, Math.min(4, (width - 2 * PAD - 8) / (BW + GAP)));
        pw = cols * BW + (cols - 1) * GAP + 2 * PAD;
        px = (width - pw) / 2;
        py = 6;
        tabW = (pw - 2 * PAD - 2 * GAP) / 3;
        int y = py + TITLE_H;
        if (collapsed) {
            ph = TITLE_H;
            return;
        }
        y += TAB_H + 4;
        int col = 0;
        for (int i = 0; i < items.size(); i++) {
            if (items.get(i).tab != tab) continue;
            rects.add(new int[]{px + PAD + col * (BW + GAP), y, BW, BH, i});
            if (++col == cols) { col = 0; y += BH + GAP; }
        }
        if (col != 0) y += BH + GAP;
        ph = y + PAD - py;
    }

    private static boolean inside(int mx, int my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private void centered(DrawContext ctx, String s, int x, int y, int w, int h, int color) {
        ctx.drawText(textRenderer, s, x + (w - textRenderer.getWidth(s)) / 2, y + (h - 8) / 2 + 1, color, true);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        layout();
        ctx.fill(0, 0, width, height, 0x66000000);

        // modules (drawn live so you see theme changes instantly)
        HudRenderer.render(ctx, true);
        int sw = ctx.getScaledWindowWidth(), sh = ctx.getScaledWindowHeight();
        for (HudModule m : HudModules.ALL) {
            if (!m.enabled()) continue;
            Ui.border(ctx, m.px(sw) - 1, m.py(sh) - 1, m.width() + 2, m.height() + 2,
                    m == dragging ? 0xFFFFFFFF : 0x66FFFFFF);
        }

        // panel
        Ui.rect(ctx, px, py, pw, ph, Theme.panelBg());
        Ui.accentLine(ctx, px, py, pw);
        ctx.drawText(textRenderer, "KURDISTAN CLIENT", px + PAD, py + 5, Theme.accent(), true);
        String chev = collapsed ? "+" : "-";
        ctx.drawText(textRenderer, chev, px + pw - PAD - textRenderer.getWidth(chev), py + 5, 0xFFB0B0C0, true);

        if (!collapsed) {
            for (int i = 0; i < TABS.length; i++) {
                int tx = px + PAD + i * (tabW + GAP), ty = py + TITLE_H + 1;
                boolean sel = i == tab;
                boolean hov = inside(mouseX, mouseY, tx, ty, tabW, TAB_H - 2);
                Ui.rect(ctx, tx, ty, tabW, TAB_H - 2,
                        sel ? Theme.accentA(0xC0) : (hov ? 0x55FFFFFF : 0x2AFFFFFF));
                centered(ctx, TABS[i], tx, ty, tabW, TAB_H - 2, 0xFFFFFFFF);
            }
            for (int[] r : rects) {
                Item it = items.get(r[4]);
                boolean hov = inside(mouseX, mouseY, r[0], r[1], r[2], r[3]);
                boolean on = it.on != null && it.on.getAsBoolean();
                int bg;
                if (it.on == null) bg = hov ? 0x66FFFFFF : 0x33FFFFFF;
                else if (on) bg = Theme.accentA(hov ? 0xE0 : 0xB0);
                else bg = hov ? 0x55FFFFFF : 0x2AFFFFFF;
                Ui.rect(ctx, r[0], r[1], r[2], r[3], bg);
                if (it.on != null) {
                    ctx.fill(r[0] + 5, r[1] + 6, r[0] + 9, r[1] + 10, on ? 0xFFFFFFFF : 0x55FFFFFF);
                }
                centered(ctx, it.label.get(), r[0] + (it.on != null ? 6 : 0), r[1], r[2] - (it.on != null ? 6 : 0), r[3],
                        on || it.on == null ? 0xFFFFFFFF : 0xFFB8B8C8);
            }
        }
        String hint = "Drag modules anywhere   |   ESC to save";
        ctx.drawText(textRenderer, hint, (width - textRenderer.getWidth(hint)) / 2, height - 12, 0xFF9A9AAA, true);

        // mouse handling (polled so we don't depend on version-specific click events)
        boolean down = GLFW.glfwGetMouseButton(client.getWindow().getHandle(), GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        if (down && !wasDown) {
            if (inside(mouseX, mouseY, px, py, pw, TITLE_H)) {
                collapsed = !collapsed;
            } else if (inside(mouseX, mouseY, px, py, pw, ph)) {
                if (!collapsed) {
                    for (int i = 0; i < TABS.length; i++) {
                        if (inside(mouseX, mouseY, px + PAD + i * (tabW + GAP), py + TITLE_H + 1, tabW, TAB_H - 2)) tab = i;
                    }
                    for (int[] r : rects) {
                        if (inside(mouseX, mouseY, r[0], r[1], r[2], r[3])) {
                            items.get(r[4]).action.run();
                            Config.save();
                        }
                    }
                }
            } else {
                for (int i = HudModules.ALL.size() - 1; i >= 0; i--) {
                    HudModule m = HudModules.ALL.get(i);
                    if (!m.enabled()) continue;
                    int x = m.px(sw), y = m.py(sh);
                    if (inside(mouseX, mouseY, x, y, m.width(), m.height())) {
                        dragging = m;
                        offX = mouseX - x;
                        offY = mouseY - y;
                        break;
                    }
                }
            }
        }
        if (!down && dragging != null) {
            Config.save();
            dragging = null;
        }
        if (dragging != null) {
            dragging.cfg().x = Math.max(0, Math.min(mouseX - offX, sw - dragging.width()));
            dragging.cfg().y = Math.max(0, Math.min(mouseY - offY, sh - dragging.height()));
        }
        wasDown = down;
    }

    @Override
    public void removed() {
        Config.save();
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
