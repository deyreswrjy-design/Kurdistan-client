package dev.kurdistan.client;

import dev.kurdistan.client.mixin.SimpleOptionAccessor;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.option.Perspective;
import net.minecraft.client.option.SimpleOption;

public final class Features {
    public static boolean flActive;
    public static float flYaw, flPitch;

    private static Perspective savedPerspective;
    private static Double savedGamma;
    private static Integer savedFov;

    public static void tick(MinecraftClient mc) {
        if (mc.player == null || mc.world == null) {
            flActive = false;
            restore(mc);
            return;
        }

        while (Keys.MENU.wasPressed()) mc.setScreen(new EditorScreen());
        while (Keys.FULLBRIGHT.wasPressed()) {
            Config.I.fullbright = !Config.I.fullbright;
            Config.save();
        }

        boolean screenOpen = mc.currentScreen != null
                && !(mc.currentScreen instanceof ChatScreen)
                && !(mc.currentScreen instanceof EditorScreen);

        // Freelook
        boolean wantLook = Config.I.freelook && Keys.FREELOOK.isPressed() && mc.currentScreen == null;
        if (wantLook && !flActive) {
            flActive = true;
            flYaw = mc.player.getYaw();
            flPitch = mc.player.getPitch();
            savedPerspective = mc.options.getPerspective();
            mc.options.setPerspective(Perspective.THIRD_PERSON_BACK);
        } else if (!wantLook && flActive) {
            flActive = false;
            if (savedPerspective != null) mc.options.setPerspective(savedPerspective);
        }

        // Fullbright (brightness raised while playing; restored whenever a menu opens or you quit)
        SimpleOption<Double> gamma = mc.options.getGamma();
        if (Config.I.fullbright && !screenOpen) {
            if (savedGamma == null) savedGamma = gamma.getValue();
            raw(gamma, 15.0);
        } else if (savedGamma != null) {
            raw(gamma, savedGamma);
            savedGamma = null;
        }

        // Zoom
        SimpleOption<Integer> fov = mc.options.getFov();
        if (Config.I.zoom && Keys.ZOOM.isPressed() && !screenOpen && mc.currentScreen == null) {
            if (savedFov == null) savedFov = fov.getValue();
            raw(fov, 30);
        } else if (savedFov != null) {
            raw(fov, savedFov);
            savedFov = null;
        }
    }

    public static void restore(MinecraftClient mc) {
        if (mc.options == null) return;
        if (savedGamma != null) { raw(mc.options.getGamma(), savedGamma); savedGamma = null; }
        if (savedFov != null) { raw(mc.options.getFov(), savedFov); savedFov = null; }
    }

    @SuppressWarnings("unchecked")
    private static <T> void raw(SimpleOption<T> option, T value) {
        ((SimpleOptionAccessor<T>) (Object) option).kurdistan$setValue(value);
    }
}
