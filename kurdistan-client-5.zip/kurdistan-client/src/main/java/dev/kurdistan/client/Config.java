package dev.kurdistan.client;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;

public class Config {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    public static Config I = new Config();

    public boolean freelook = true;
    public boolean fullbright = false;
    public boolean zoom = true;
    public boolean toggleSprint = false;

    // Theme
    public int accent = 0;
    public int bgColor = 0;
    public int bgOpacity = 60;
    public int textColor = 0;
    public boolean rounded = true;

    // Performance / visual
    public boolean lowFire = false;
    public boolean noWeather = false;
    public int hurtCam = 0;       // 0 full, 1 half, 2 none
    public int particleMode = 0;  // 0 normal, 1 reduced, 2 minimal
    public int fpsBoost = 0;      // 0 off, 1 balanced, 2 max
    public boolean customMenu = true;
    public boolean itemPhysics = false;
    public int chatOpacity = 3, chatScale = 2, chatBg = 2;
    public Map<String, Hud> hud = new LinkedHashMap<>();

    public static class Hud {
        public int x, y;
        public boolean enabled;
        public Hud() {}
        public Hud(int x, int y, boolean enabled) { this.x = x; this.y = y; this.enabled = enabled; }
    }

    public Hud hud(String id, int x, int y, boolean enabled) {
        return hud.computeIfAbsent(id, k -> new Hud(x, y, enabled));
    }

    private static Path profilePath(int n) {
        return FabricLoader.getInstance().getConfigDir().resolve("kurdistan_profile_" + n + ".json");
    }

    public static boolean saveProfile(int n) {
        try {
            Files.writeString(profilePath(n), GSON.toJson(I));
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public static boolean loadProfile(int n) {
        try {
            Path p = profilePath(n);
            if (!Files.exists(p)) return false;
            Config c = GSON.fromJson(Files.readString(p), Config.class);
            if (c == null) return false;
            if (c.hud == null) c.hud = new LinkedHashMap<>();
            I = c;
            save();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("kurdistan_client.json");
    }

    public static void load() {
        try {
            Path p = path();
            if (Files.exists(p)) {
                Config c = GSON.fromJson(Files.readString(p), Config.class);
                if (c != null) {
                    if (c.hud == null) c.hud = new LinkedHashMap<>();
                    I = c;
                }
            }
        } catch (Exception e) {
            System.err.println("[Kurdistan] Could not read config: " + e);
        }
    }

    public static void save() {
        try {
            Files.writeString(path(), GSON.toJson(I));
        } catch (Exception e) {
            System.err.println("[Kurdistan] Could not save config: " + e);
        }
    }
}
