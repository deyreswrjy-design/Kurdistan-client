package dev.kurdistan.client;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;

public class Config {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    public static Config I = new Config();

    public boolean freelook = true;
    public boolean fullbright = false;
    public boolean zoom = true;
    public Map<String, Hud> hud = new LinkedHashMap<>();

    public static class Hud {
        public int x, y;
        public boolean enabled;
        public Hud() {}
        public Hud(int x, int y, boolean enabled) { this.x = x; this.y = y; this.enabled = enabled; }
    }

    public Hud hud(String id, int x, int y, boolean enabled) {
        return hud.computeIfAbsent(id, k -> new Hud(x, y, enabled));
    }

    private static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("kurdistan_client.json");
    }

    public static void load() {
        try {
            Path p = path();
            if (Files.exists(p)) {
                Config c = GSON.fromJson(Files.readString(p), Config.class);
                if (c != null) {
                    if (c.hud == null) c.hud = new LinkedHashMap<>();
                    I = c;
                }
            }
        } catch (Exception e) {
            System.err.println("[Kurdistan] Could not read config: " + e);
        }
    }

    public static void save() {
        try {
            Files.writeString(path(), GSON.toJson(I));
        } catch (Exception e) {
            System.err.println("[Kurdistan] Could not save config: " + e);
        }
    }
}
