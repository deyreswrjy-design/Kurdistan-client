package dev.kurdistan.client;

import java.util.HashMap;
import java.util.Map;

/** Descriptions shown when you right-click an option or module in the menu. */
public final class Info {
    private static final Map<String, String> M = new HashMap<>();

    static {
        M.put("Freelook", "Hold the Freelook key (Left Alt) to look around freely in third person without turning your character.");
        M.put("Fullbright", "Makes everything fully bright so caves and nights are easy to see. Toggle with G.");
        M.put("Zoom", "Hold C to zoom in like a spyglass. Release to go back to normal.");
        M.put("Toggle Sprint", "Automatically sprints while you hold forward, so you never need to double-tap W.");
        M.put("Low Fire", "Hides the big fire overlay on your screen when you are burning.");
        M.put("No Weather", "Turns off rain and thunder visuals on your screen.");
        M.put("Item Physics", "Experimental: dropped items lie flat on the ground instead of spinning.");
        M.put("Hurt Cam", "Controls the screen shake when you take damage: Full, Half or None.");
        M.put("Particles", "Reduces how many particles are shown. Helps FPS in big fights.");
        M.put("FPS Boost", "Lowers render distance, entity distance and biome blend to raise FPS. Off restores your settings.");
        M.put("Accent", "Main color of the client: panels, buttons and highlights. Rainbow is animated.");
        M.put("Background", "Color of the module panels and menu.");
        M.put("BG Opacity", "How see-through the module panels are, from 0% to 100%.");
        M.put("Text", "Color of the text on your HUD modules.");
        M.put("Corners", "Switch between rounded and square panels.");
        M.put("Custom Menu", "Use the Kurdistan Client main menu instead of the vanilla one.");
        M.put("Chat Opacity", "How visible the chat text is.");
        M.put("Chat Scale", "Size of the chat text.");
        M.put("Chat BG", "Darkness of the box behind chat messages.");
        M.put("GUI Scale", "Size of menus and HUD. Auto picks the best size for your screen.");
        M.put("FOV", "Your field of view. Higher shows more of the world.");
        M.put("Max FPS", "Caps your frame rate. Unlimited lets the game run as fast as it can.");
        M.put("FOV Effects", "How much your view widens when sprinting or speed effects. None removes it.");
        M.put("View Bobbing", "Makes the screen sway slightly while you walk.");
        M.put("VSync", "Syncs frames to your screen. Reduces tearing but may lower FPS.");
        M.put("Entity Shadows", "Shows shadows under mobs and players.");
        M.put("Sensitivity", "How fast the camera turns with your mouse.");
        M.put("Auto Jump", "Automatically jumps up single blocks when you walk into them.");
        M.put("Subtitles", "Shows text for sounds, useful for hearing where things are.");
        M.put("Sneak Toggle", "Tap sneak once to stay sneaking instead of holding it.");
        M.put("Sprint Toggle", "Tap sprint once to stay sprinting instead of holding it.");
        M.put("Raw Mouse", "Uses your mouse input directly without system smoothing.");
        M.put("Master Volume", "Overall game volume.");
        M.put("Music Volume", "Volume of background music only.");
        M.put("Toggle All Mods", "Turns every HUD module on, or all off if any are on.");
        M.put("Reset Positions", "Puts all HUD modules back to their default places.");
        M.put("Save Profile 1", "Saves your current setup into slot 1.");
        M.put("Save Profile 2", "Saves your current setup into slot 2.");
        M.put("Save Profile 3", "Saves your current setup into slot 3.");
        M.put("Load Profile 1", "Loads the setup saved in slot 1.");
        M.put("Load Profile 2", "Loads the setup saved in slot 2.");
        M.put("Load Profile 3", "Loads the setup saved in slot 3.");
        M.put("FPS", "Shows your frames per second.");
        M.put("CPS", "Shows how many times per second you click left and right mouse buttons.");
        M.put("Ping", "Shows your connection delay to the server in milliseconds.");
        M.put("Coords", "Shows your X, Y and Z position.");
        M.put("Keystrokes", "Shows W, A, S, D, jump and mouse buttons lighting up as you press them.");
        M.put("Mouse Strokes", "Shows a dot and trail that follows how you move your mouse.");
        M.put("Armor", "Shows your armor pieces and held item with durability left.");
        M.put("Potions", "Lists active potion effects with their level and time left.");
        M.put("Clock", "Shows your real-world time.");
        M.put("Direction", "Shows which way you are facing (N, NE, E and so on).");
        M.put("Speed", "Shows how fast you are moving in blocks per second.");
        M.put("Memory", "Shows how much RAM the game is using.");
        M.put("Health", "Shows your health and food level as numbers.");
        M.put("XP Level", "Shows your experience level.");
        M.put("Target Block", "Shows the name of the block you are looking at.");
        M.put("Playtime", "Shows how long you have been playing this session.");
        M.put("Server", "Shows the address of the server you are on, or Singleplayer.");
        M.put("Players", "Shows how many players are online on the server.");
        M.put("Held Item", "Shows the name of the item in your main hand.");
        M.put("Status", "Lists which client features are active right now.");
        M.put("Crystals", "Counts end crystals in your inventory.");
        M.put("Anchors", "Counts respawn anchors in your inventory.");
        M.put("Glowstone", "Counts glowstone blocks in your inventory.");
        M.put("Obsidian", "Counts obsidian blocks in your inventory.");
        M.put("Totems", "Counts totems of undying in your inventory.");
        M.put("Totem Pops", "Counts how many times totems popped: yours, and the last other player.");
        M.put("Durability Warn", "Warns when any armor piece drops below 20% durability.");
        M.put("Armor Break Warn", "Flashes a warning when armor is almost broken (under 6%).");
        M.put("Low Health Warn", "Flashes the screen edges red and shows a warning at 3 hearts or less.");
        M.put("Inventory HUD", "Shows your main inventory on screen so you do not need to open it.");
        M.put("Date", "Shows today's date.");
        M.put("Light Level", "Shows the light level where you stand. Mobs spawn in darkness.");
        M.put("Chunk", "Shows which chunk you are in.");
        M.put("Nether Coords", "Shows your matching coordinates in the other dimension (divided or multiplied by 8).");
        M.put("Armor Points", "Shows your total armor protection points.");
        M.put("Move State", "Shows if you are walking, sprinting or sneaking.");
        M.put("Fall Distance", "Shows how far you have fallen. Over 3 blocks hurts.");
        M.put("Target Entity", "Shows the name and health of the mob or player you are looking at.");
        M.put("Saturation", "Shows your hidden saturation level, which controls how fast hunger drops.");
        M.put("Air", "Shows how many seconds of air you have left underwater.");
        M.put("Rotation", "Shows your exact yaw and pitch angles.");
        M.put("Tool Durability", "Shows the durability left on the tool in your hand.");
        M.put("Offhand", "Shows what you are holding in your offhand.");
        M.put("Standing On", "Shows the name of the block under your feet.");
        M.put("Dimension", "Shows which dimension you are in.");
        M.put("Biome", "Shows the biome you are in.");
        M.put("FPS Stats", "Shows your average FPS and lowest FPS over the last 5 seconds.");
    }

    public static String get(String name) {
        return M.getOrDefault(name, "No description yet.");
    }
}
