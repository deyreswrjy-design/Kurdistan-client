package dev.kurdistan.client.mixin;

import dev.kurdistan.client.Features;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Entity.class)
public class EntityMixin {
    @Inject(method = "changeLookDirection", at = @At("HEAD"), cancellable = true)
    private void kurdistan$freelook(double dx, double dy, CallbackInfo ci) {
        if (Features.flActive && (Object) this == MinecraftClient.getInstance().player) {
            Features.flYaw += (float) dx * 0.15f;
            Features.flPitch = MathHelper.clamp(Features.flPitch + (float) dy * 0.15f, -90f, 90f);
            ci.cancel();
        }
    }
}
