package dev.kurdistan.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.Util;

/** Drawn over the vanilla loading screen so "Mojang Studios" becomes "Kurdistan Developer". */
public final class SplashBrand {
    public static void draw(DrawContext c) {
        TextRenderer tr = MinecraftClient.getInstance().textRenderer;
        if (tr == null) return;
        int w = c.getScaledWindowWidth(), h = c.getScaledWindowHeight();
        int cx = w / 2, cy = h / 2;

        c.fill(0, 0, w, h, 0xFF0A0A0F);
        scaled(c, tr, "KURDISTAN", cx, cy - 34, 4f, 0xFFFFFFFF);
        scaled(c, tr, "D E V E L O P E R", cx, cy + 2, 1.6f, 0xFFB8B8C8);

        int x0 = cx - 60, y = cy + 26;
        c.fill(x0, y, x0 + 40, y + 3, 0xFFED2024);
        c.fill(x0 + 40, y, x0 + 80, y + 3, 0xFFFFFFFF);
        c.fill(x0 + 80, y, x0 + 120, y + 3, 0xFF278E43);

        int by = y + 12;
        c.fill(x0, by, x0 + 120, by + 2, 0xFF22222A);
        float t = (Util.getMeasuringTimeMs() % 1200L) / 1200f;
        int pos = (int) (t * 160f) - 40;
        int s = Math.max(0, pos), e = Math.min(120, pos + 40);
        if (e > s) c.fill(x0 + s, by, x0 + e, by + 2, 0xFFFFFFFF);

        scaled(c, tr, "Loading...", cx, by + 10, 1f, 0xFF777788);
    }

    private static void scaled(DrawContext c, TextRenderer tr, String s, int cx, int y, float sc, int color) {
        var m = c.getMatrices();
        m.pushMatrix();
        m.translate((float) cx, (float) y);
        m.scale(sc, sc);
        c.drawText(tr, s, -tr.getWidth(s) / 2, 0, color, true);
        m.popMatrix();
    }
}
