package dev.kurdistan.client.mixin;

import dev.kurdistan.client.Features;
import net.minecraft.client.render.Camera;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(Camera.class)
public class CameraMixin {
    @ModifyVariable(method = "setRotation", at = @At("HEAD"), argsOnly = true, ordinal = 0)
    private float kurdistan$yaw(float yaw) {
        return Features.flActive ? Features.flYaw : yaw;
    }

    @ModifyVariable(method = "setRotation", at = @At("HEAD"), argsOnly = true, ordinal = 1)
    private float kurdistan$pitch(float pitch) {
        return Features.flActive ? Features.flPitch : pitch;
    }
}
