package dev.kurdistan.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class Pops {
    public static int self;
    public static String last = "";
    public static int lastCount;
    private static final Map<UUID, Integer> counts = new HashMap<>();

    public static void pop(Entity e) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (e == mc.player) {
            self++;
        } else if (e instanceof PlayerEntity p) {
            int c = counts.merge(p.getUuid(), 1, Integer::sum);
            last = p.getName().getString();
            lastCount = c;
        }
    }

    public static void reset() {
        self = 0;
        last = "";
        lastCount = 0;
        counts.clear();
    }
}
