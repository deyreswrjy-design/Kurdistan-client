package dev.kurdistan.client;

import dev.kurdistan.client.hud.HudModule;
import dev.kurdistan.client.hud.HudModules;
import dev.kurdistan.client.hud.HudRenderer;
import dev.kurdistan.client.hud.Theme;
import dev.kurdistan.client.hud.Ui;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.option.SimpleOption;
import net.minecraft.sound.SoundCategory;
import net.minecraft.text.Text;
import net.minecraft.util.Util;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.Supplier;

/** Custom-drawn menu: tabs, theme, features, module toggles + search, profiles and drag-and-drop HUD editing. */
public class EditorScreen extends Screen {
    private static final int BW = 96, BH = 16, GAP = 3, PAD = 6, TITLE_H = 16, TAB_H = 16;
    private static final String[] TABS = {"Main", "Theme", "Mods", "Game", "Xray", "Client"};
    private static final String[] HURT = {"Full", "Half", "None"};
    private static final String[] PART = {"Normal", "Reduced", "Minimal"};
    private static final String[] FPS = {"Off", "Balanced", "Max"};
    private static int tab;
    private static boolean collapsed;
    private static String filter = "";
    private static String toast = "";
    private static long toastUntil;

    private record Item(int tab, String name, Supplier<String> label, BooleanSupplier on, Runnable action) {}

    private final List<Item> items = new ArrayList<>();
    private final List<int[]> rects = new ArrayList<>(); // x, y, w, h, itemIndex
    private int px, py, pw, ph, tabW;
    private TextFieldWidget search;

    private HudModule dragging;
    private int offX, offY;
    private boolean wasDown = true, wasRight = true;
    private String infoName, infoText;

    private record Setting(Supplier<String> label, BooleanSupplier on, Runnable action) {}

    private HudModule selModule;
    private List<Setting> detail = new ArrayList<>();
    private List<String> descLines = new ArrayList<>();
    private int page, descY;
    private int[] backR, prevR, nextR;
    private final long openedAt = Util.getMeasuringTimeMs();

    public EditorScreen() {
        super(Text.literal("Kurdistan Client"));

        // ---- Main
        toggle(0, "Freelook", () -> Config.I.freelook, v -> Config.I.freelook = v);
        toggle(0, "Fullbright", () -> Config.I.fullbright, v -> Config.I.fullbright = v);
        toggle(0, "Zoom", () -> Config.I.zoom, v -> Config.I.zoom = v);
        toggle(0, "Toggle Sprint", () -> Config.I.toggleSprint, v -> Config.I.toggleSprint = v);
        toggle(0, "Low Fire", () -> Config.I.lowFire, v -> Config.I.lowFire = v);
        toggle(0, "No Weather", () -> Config.I.noWeather, v -> Config.I.noWeather = v);
        toggle(0, "Item Physics", () -> Config.I.itemPhysics, v -> Config.I.itemPhysics = v);
        cycle(0, "Hurt Cam", () -> HURT[Math.floorMod(Config.I.hurtCam, 3)], () -> Config.I.hurtCam = (Config.I.hurtCam + 1) % 3);
        cycle(0, "Particles", () -> PART[Math.floorMod(Config.I.particleMode, 3)], () -> Config.I.particleMode = (Config.I.particleMode + 1) % 3);
        cycle(0, "FPS Boost", () -> FPS[Math.floorMod(Config.I.fpsBoost, 3)], () -> Config.I.fpsBoost = (Config.I.fpsBoost + 1) % 3);

        // ---- Theme
        cycle(1, "Accent", () -> Theme.ACCENT_NAMES[Math.floorMod(Config.I.accent, Theme.ACCENT_NAMES.length)],
                () -> Config.I.accent = (Config.I.accent + 1) % Theme.ACCENT_NAMES.length);
        cycle(1, "Background", () -> Theme.BG_NAMES[Math.floorMod(Config.I.bgColor, Theme.BG_NAMES.length)],
                () -> Config.I.bgColor = (Config.I.bgColor + 1) % Theme.BG_NAMES.length);
        cycle(1, "BG Opacity", () -> Config.I.bgOpacity + "%",
                () -> Config.I.bgOpacity = ((Config.I.bgOpacity / 20 + 1) % 6) * 20);
        cycle(1, "Text", () -> Theme.TEXT_NAMES[Math.floorMod(Config.I.textColor, Theme.TEXT_NAMES.length)],
                () -> Config.I.textColor = (Config.I.textColor + 1) % Theme.TEXT_NAMES.length);
        cycle(1, "Corners", () -> Config.I.rounded ? "Rounded" : "Square", () -> Config.I.rounded = !Config.I.rounded);
        toggle(1, "Custom Menu", () -> Config.I.customMenu, v -> Config.I.customMenu = v);
        cycle(1, "Chat Opacity", () -> pct(Features.CHAT_OPACITY[Math.floorMod(Config.I.chatOpacity, Features.CHAT_OPACITY.length)]),
                () -> { Config.I.chatOpacity = (Config.I.chatOpacity + 1) % Features.CHAT_OPACITY.length; Features.applyChat(client); });
        cycle(1, "Chat Scale", () -> pct(Features.CHAT_SCALE[Math.floorMod(Config.I.chatScale, Features.CHAT_SCALE.length)]),
                () -> { Config.I.chatScale = (Config.I.chatScale + 1) % Features.CHAT_SCALE.length; Features.applyChat(client); });
        cycle(1, "Chat BG", () -> pct(Features.CHAT_BG[Math.floorMod(Config.I.chatBg, Features.CHAT_BG.length)]),
                () -> { Config.I.chatBg = (Config.I.chatBg + 1) % Features.CHAT_BG.length; Features.applyChat(client); });
        cycle(1, "GUI Scale", () -> {
            int g = client == null ? 0 : client.options.getGuiScale().getValue();
            return g == 0 ? "Auto" : String.valueOf(g);
        }, () -> client.send(() -> Features.cycleGuiScale(client)));

        // ---- Game (vanilla options, one tap)
        cycle(3, "FOV", () -> String.valueOf(client.options.getFov().getValue()), () -> {
            int[] v = {70, 90, 100, 110};
            int cur = client.options.getFov().getValue(), nx = v[0];
            for (int x : v) if (x > cur) { nx = x; break; }
            client.options.getFov().setValue(nx);
        });
        cycle(3, "Max FPS", () -> {
            int f = client.options.getMaxFps().getValue();
            return f >= 260 ? "Unlimited" : String.valueOf(f);
        }, () -> {
            int[] v = {60, 120, 144, 240, 260};
            int cur = client.options.getMaxFps().getValue(), nx = v[0];
            for (int x : v) if (x > cur) { nx = x; break; }
            client.options.getMaxFps().setValue(nx);
        });
        cycle(3, "FOV Effects", () -> pct(client.options.getFovEffectScale().getValue()), () -> {
            double cur = client.options.getFovEffectScale().getValue();
            client.options.getFovEffectScale().setValue(cur > 0.75 ? 0.5 : cur > 0.25 ? 0.0 : 1.0);
        });
        items.add(new Item(3, "View Bobbing", () -> "View Bobbing", () -> client != null && client.options.getBobView().getValue(),
                () -> client.options.getBobView().setValue(!client.options.getBobView().getValue())));
        items.add(new Item(3, "VSync", () -> "VSync", () -> client != null && client.options.getEnableVsync().getValue(),
                () -> client.options.getEnableVsync().setValue(!client.options.getEnableVsync().getValue())));
        items.add(new Item(3, "Entity Shadows", () -> "Entity Shadows", () -> client != null && client.options.getEntityShadows().getValue(),
                () -> client.options.getEntityShadows().setValue(!client.options.getEntityShadows().getValue())));

        cycle(3, "Sensitivity", () -> pct(client.options.getMouseSensitivity().getValue()),
                () -> nextDouble(client.options.getMouseSensitivity(), new double[]{0.25, 0.5, 0.75, 1.0}));
        optToggle(3, "Auto Jump", () -> client.options.getAutoJump());
        optToggle(3, "Subtitles", () -> client.options.getShowSubtitles());
        optToggle(3, "Sneak Toggle", () -> client.options.getSneakToggled());
        optToggle(3, "Sprint Toggle", () -> client.options.getSprintToggled());
        optToggle(3, "Raw Mouse", () -> client.options.getRawMouseInput());
        cycle(3, "Master Volume", () -> pct(client.options.getSoundVolumeOption(SoundCategory.MASTER).getValue()),
                () -> nextDouble(client.options.getSoundVolumeOption(SoundCategory.MASTER), new double[]{0.0, 0.25, 0.5, 0.75, 1.0}));
        cycle(3, "Music Volume", () -> pct(client.options.getSoundVolumeOption(SoundCategory.MUSIC).getValue()),
                () -> nextDouble(client.options.getSoundVolumeOption(SoundCategory.MUSIC), new double[]{0.0, 0.25, 0.5, 0.75, 1.0}));

        // ---- Xray (singleplayer only)
        xrayToggle("Xray", () -> Config.I.xray, v -> Config.I.xray = v);
        xrayToggle("Auto Bright", () -> Config.I.xrayBright, v -> Config.I.xrayBright = v);
        for (int i = 0; i < Xray.KEYS.length; i++) {
            final String key = Xray.KEYS[i];
            xrayToggle(Xray.NAMES[i], () -> Xray.on(key), v -> Xray.set(key, v));
        }
        cycle(4, "Select All", () -> "", () -> {
            for (String k : Xray.KEYS) Xray.set(k, true);
            client.send(Xray::refresh);
        });
        cycle(4, "Select None", () -> "", () -> {
            for (String k : Xray.KEYS) Xray.set(k, false);
            client.send(Xray::refresh);
        });

        // ---- Mods
        for (HudModule m : HudModules.ALL) {
            toggle(2, m.name, m::enabled, v -> m.cfg().enabled = v);
        }

        // ---- Client
        cycle(5, "Toggle All Mods", () -> "", () -> {
            boolean any = false;
            for (HudModule m : HudModules.ALL) any |= m.enabled();
            for (HudModule m : HudModules.ALL) m.cfg().enabled = !any;
            say(any ? "All modules off" : "All modules on");
        });
        cycle(5, "Reset Positions", () -> "", () -> {
            for (HudModule m : HudModules.ALL) m.resetPos();
            say("Positions reset");
        });
        for (int n = 1; n <= 3; n++) {
            final int slot = n;
            cycle(5, "Save Profile " + n, () -> "", () -> say(Config.saveProfile(slot) ? "Saved profile " + slot : "Could not save"));
            cycle(5, "Load Profile " + n, () -> "", () -> say(loadSlot(slot)));
        }
    }

    private void xrayToggle(String name, BooleanSupplier get, Consumer<Boolean> set) {
        items.add(new Item(4, name, () -> name, get, () -> {
            set.accept(!get.getAsBoolean());
            client.send(Xray::refresh);
        }));
    }

    private void optToggle(int t, String name, Supplier<SimpleOption<Boolean>> o) {
        items.add(new Item(t, name, () -> name, () -> client != null && o.get().getValue(),
                () -> o.get().setValue(!o.get().getValue())));
    }

    private static void nextDouble(SimpleOption<Double> o, double[] vals) {
        double cur = o.getValue();
        double nx = vals[0];
        for (double v : vals) if (v > cur + 0.01) { nx = v; break; }
        o.setValue(nx);
    }

    private List<String> wrap(String text, int maxW) {
        List<String> out = new ArrayList<>();
        StringBuilder line = new StringBuilder();
        for (String w : text.split(" ")) {
            String test = line.length() == 0 ? w : line + " " + w;
            if (textRenderer.getWidth(test) > maxW && line.length() > 0) {
                out.add(line.toString());
                line = new StringBuilder(w);
            } else {
                line = new StringBuilder(test);
            }
        }
        if (line.length() > 0) out.add(line.toString());
        return out;
    }

    private String loadSlot(int slot) {
        boolean ok = Config.loadProfile(slot);
        selModule = null;
        return ok ? "Loaded profile " + slot : "Profile " + slot + " is empty";
    }

    private static String pct(double v) { return Math.round(v * 100) + "%"; }

    private static void say(String s) {
        toast = s;
        toastUntil = Util.getMeasuringTimeMs() + 2500;
    }

    private void toggle(int t, String name, BooleanSupplier get, Consumer<Boolean> set) {
        items.add(new Item(t, name, () -> name, get, () -> set.accept(!get.getAsBoolean())));
    }

    private void cycle(int t, String name, Supplier<String> value, Runnable next) {
        items.add(new Item(t, name, () -> {
            String v = value.get();
            return v.isEmpty() ? name : name + ": " + v;
        }, null, next));
    }

    @Override
    protected void init() {
        wasDown = true;
        search = new TextFieldWidget(textRenderer, 0, 0, 100, 12, Text.literal(""));
        search.setPlaceholder(Text.literal("Search modules..."));
        search.setDrawsBackground(false);
        search.setMaxLength(24);
        search.setText(filter);
        search.setChangedListener(s -> { filter = s.toLowerCase(); page = 0; });
        addDrawableChild(search);
    }

    private boolean visible(Item it) {
        if (it.tab != tab) return false;
        return tab != 2 || filter.isEmpty() || it.label.get().toLowerCase().contains(filter);
    }

    private float anim() {
        float t = Math.min(1f, (Util.getMeasuringTimeMs() - openedAt) / 300f);
        return 1f - (1f - t) * (1f - t) * (1f - t);
    }

    private HudModule moduleByName(String n) {
        for (HudModule m : HudModules.ALL) if (m.name.equals(n)) return m;
        return null;
    }

    private void openDetail(HudModule m) {
        selModule = m;
        collapsed = false;
        infoName = null;
        detail = buildSettings(m);
    }

    private static final int[] SCALES = {50, 75, 100, 125, 150, 200};
    private static final int[] OPACITIES = {-1, 0, 20, 40, 60, 80, 100};

    private List<Setting> buildSettings(HudModule m) {
        List<Setting> l = new ArrayList<>();
        l.add(new Setting(() -> "Enabled: " + (m.enabled() ? "On" : "Off"), m::enabled,
                () -> m.cfg().enabled = !m.cfg().enabled));
        l.add(new Setting(() -> "Scale: " + m.cfg().scale + "%", null, () -> {
            int nx = SCALES[0];
            for (int v : SCALES) if (v > m.cfg().scale) { nx = v; break; }
            m.cfg().scale = nx;
        }));
        l.add(new Setting(() -> "Color: " + Theme.PAL_NAMES[Math.floorMod(m.cfg().textColor, Theme.PAL_NAMES.length)], null,
                () -> m.cfg().textColor = (m.cfg().textColor + 1) % Theme.PAL_NAMES.length));
        l.add(new Setting(() -> "Background: " + (m.cfg().bg == 0 ? "Theme" : "None"), null,
                () -> m.cfg().bg = 1 - m.cfg().bg));
        l.add(new Setting(() -> "Opacity: " + (m.cfg().opacity < 0 ? "Theme" : m.cfg().opacity + "%"), null, () -> {
            int idx = 0;
            for (int i = 0; i < OPACITIES.length; i++) if (OPACITIES[i] == m.cfg().opacity) idx = i;
            m.cfg().opacity = OPACITIES[(idx + 1) % OPACITIES.length];
        }));
        if (m.hasLabel()) {
            l.add(new Setting(() -> "Labels: " + (m.cfg().label ? "On" : "Off"), null,
                    () -> m.cfg().label = !m.cfg().label));
        }
        for (HudModule.Opt o : m.options()) {
            l.add(new Setting(() -> o.label() + ": " + o.values()[m.opt(o.key())], null, () -> {
                int cur = m.opt(o.key());
                m.cfg().opt.put(o.key(), (cur + 1) % o.values().length);
            }));
        }
        l.add(new Setting(() -> "Reset Position", null, m::resetPos));
        l.add(new Setting(() -> "Reset Settings", null, () -> {
            Config.Hud h = m.cfg();
            h.scale = 100;
            h.textColor = 0;
            h.bg = 0;
            h.opacity = -1;
            h.label = true;
            h.opt.clear();
        }));
        return l;
    }

    private void layout() {
        rects.clear();
        backR = prevR = nextR = null;
        int cols = Math.max(2, Math.min(4, (width - 2 * PAD - 8) / (BW + GAP)));
        pw = cols * BW + (cols - 1) * GAP + 2 * PAD;
        px = (width - pw) / 2;
        py = 6;
        tabW = (pw - 2 * PAD - 5 * GAP) / 6;
        int y = py + TITLE_H;

        if (collapsed) {
            ph = TITLE_H;
        } else if (selModule != null) {
            y += 4;
            backR = new int[]{px + PAD, y, 56, BH};
            y += BH + 4;
            descLines = wrap(Info.get(selModule.name), pw - 2 * PAD);
            descY = y;
            y += descLines.size() * 10 + 4;
            int col = 0;
            for (int i = 0; i < detail.size(); i++) {
                rects.add(new int[]{px + PAD + col * (BW + GAP), y, BW, BH, i});
                if (++col == cols) { col = 0; y += BH + GAP; }
            }
            if (col != 0) y += BH + GAP;
            ph = y + PAD - py;
        } else {
            y += TAB_H + 4;
            if (tab == 2) y += 18;
            List<Integer> vis = new ArrayList<>();
            for (int i = 0; i < items.size(); i++) if (visible(items.get(i))) vis.add(i);
            int rowsFit = Math.max(2, (height - y - 44) / (BH + GAP));
            int per = rowsFit * cols;
            int pages = Math.max(1, (vis.size() + per - 1) / per);
            page = Math.max(0, Math.min(page, pages - 1));
            int from = page * per, to = Math.min(vis.size(), from + per);
            int col = 0;
            for (int k = from; k < to; k++) {
                rects.add(new int[]{px + PAD + col * (BW + GAP), y, BW, BH, vis.get(k)});
                if (++col == cols) { col = 0; y += BH + GAP; }
            }
            if (col != 0) y += BH + GAP;
            if (pages > 1) {
                prevR = new int[]{px + PAD, y, 44, BH};
                nextR = new int[]{px + pw - PAD - 44, y, 44, BH};
                y += BH + GAP;
            }
            ph = y + PAD - py;
        }

        // slide-in animation
        int dy = -(int) ((1f - anim()) * (ph + 12));
        py += dy;
        for (int[] r : rects) r[1] += dy;
        if (backR != null) backR[1] += dy;
        if (prevR != null) prevR[1] += dy;
        if (nextR != null) nextR[1] += dy;
        descY += dy;
    }

    private static boolean inside(int mx, int my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private static boolean inside(int mx, int my, int[] r) {
        return r != null && inside(mx, my, r[0], r[1], r[2], r[3]);
    }

    private void centered(DrawContext ctx, String s, int x, int y, int w, int h, int color) {
        ctx.drawText(textRenderer, s, x + (w - textRenderer.getWidth(s)) / 2, y + (h - 8) / 2 + 1, color, true);
    }

    private void button(DrawContext ctx, int[] r, String label, Boolean on, boolean hov) {
        int bg;
        if (on == null) bg = hov ? 0x66FFFFFF : 0x33FFFFFF;
        else if (on) bg = Theme.accentA(hov ? 0xE0 : 0xB0);
        else bg = hov ? 0x55FFFFFF : 0x2AFFFFFF;
        Ui.rect(ctx, r[0], r[1], r[2], r[3], bg);
        int off = 0;
        if (on != null) {
            ctx.fill(r[0] + 5, r[1] + 6, r[0] + 9, r[1] + 10, on ? 0xFFFFFFFF : 0x55FFFFFF);
            off = 6;
        }
        centered(ctx, label, r[0] + off, r[1], r[2] - off, r[3], on == null || on ? 0xFFFFFFFF : 0xFFB8B8C8);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        layout();
        float a = anim();
        ctx.fill(0, 0, width, height, ((int) (0x66 * a)) << 24);

        HudRenderer.render(ctx, true);
        int sw = ctx.getScaledWindowWidth(), sh = ctx.getScaledWindowHeight();
        for (HudModule m : HudModules.ALL) {
            if (!m.enabled()) continue;
            boolean sel = m == selModule;
            Ui.border(ctx, m.px(sw) - 1, m.py(sh) - 1, m.ew() + 2, m.eh() + 2,
                    m == dragging || sel ? 0xFFFFFFFF : 0x66FFFFFF);
        }

        Ui.rect(ctx, px, py, pw, ph, Theme.panelBg());
        Ui.accentLine(ctx, px, py, pw);
        ctx.drawText(textRenderer, "KURDISTAN CLIENT", px + PAD, py + 5, Theme.accent(), true);
        String chev = collapsed ? "+" : "-";
        ctx.drawText(textRenderer, chev, px + pw - PAD - textRenderer.getWidth(chev), py + 5, 0xFFB0B0C0, true);

        boolean showSearch = !collapsed && selModule == null && tab == 2;
        search.visible = showSearch;
        if (!showSearch) search.setFocused(false);

        if (!collapsed && selModule != null) {
            button(ctx, backR, "< Back", null, inside(mouseX, mouseY, backR));
            ctx.drawText(textRenderer, selModule.name, px + PAD + 62, backR[1] + 4, Theme.accent(), true);
            int ly = descY;
            for (String l : descLines) { ctx.drawText(textRenderer, l, px + PAD, ly, 0xFFD8D8E4, true); ly += 10; }
            for (int[] r : rects) {
                Setting st = detail.get(r[4]);
                button(ctx, r, st.label.get(), st.on == null ? null : st.on.getAsBoolean(), inside(mouseX, mouseY, r));
            }
        } else if (!collapsed) {
            for (int i = 0; i < TABS.length; i++) {
                int tx = px + PAD + i * (tabW + GAP), ty = py + TITLE_H + 1;
                boolean sel = i == tab;
                boolean hov = inside(mouseX, mouseY, tx, ty, tabW, TAB_H - 2);
                Ui.rect(ctx, tx, ty, tabW, TAB_H - 2, sel ? Theme.accentA(0xC0) : (hov ? 0x55FFFFFF : 0x2AFFFFFF));
                centered(ctx, TABS[i], tx, ty, tabW, TAB_H - 2, 0xFFFFFFFF);
            }
            if (showSearch) {
                int fx = px + PAD, fy = py + TITLE_H + TAB_H + 4, fw = pw - 2 * PAD;
                Ui.rect(ctx, fx, fy, fw, 14, 0x40FFFFFF);
                search.setPosition(fx + 5, fy + 3);
                search.setWidth(fw - 10);
                search.render(ctx, mouseX, mouseY, delta);
            }
            for (int[] r : rects) {
                Item it = items.get(r[4]);
                button(ctx, r, it.label.get(), it.on == null ? null : it.on.getAsBoolean(), inside(mouseX, mouseY, r));
            }
            if (prevR != null) {
                button(ctx, prevR, "< Prev", null, inside(mouseX, mouseY, prevR));
                button(ctx, nextR, "Next >", null, inside(mouseX, mouseY, nextR));
                String pg = "Page " + (page + 1);
                ctx.drawText(textRenderer, pg, px + (pw - textRenderer.getWidth(pg)) / 2, prevR[1] + 5, 0xFFB0B0C0, true);
            }
        }

        if (infoName != null && selModule == null) {
            List<String> ls = wrap(infoText, pw - 2 * PAD);
            int ch = 16 + ls.size() * 10 + 4;
            int cy = Math.min(py + ph + 4, height - ch - 16);
            Ui.rect(ctx, px, cy, pw, ch, Theme.panelBg());
            Ui.accentLine(ctx, px, cy, pw);
            ctx.drawText(textRenderer, infoName, px + PAD, cy + 5, Theme.accent(), true);
            int ly = cy + 17;
            for (String l : ls) { ctx.drawText(textRenderer, l, px + PAD, ly, 0xFFFFFFFF, true); ly += 10; }
        }

        boolean toasting = Util.getMeasuringTimeMs() < toastUntil;
        String hint = toasting ? toast : "Drag modules   |   Right-click a module for settings   |   ESC saves";
        ctx.drawText(textRenderer, hint, (width - textRenderer.getWidth(hint)) / 2, height - 12,
                toasting ? Theme.accent() : 0xFF9A9AAA, true);

        long h = client.getWindow().getHandle();
        boolean rdown = GLFW.glfwGetMouseButton(h, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
        if (rdown && !wasRight && a >= 1f) {
            HudModule target = null;
            String n = null;
            if (!collapsed && selModule == null) {
                for (int[] r : rects) {
                    if (inside(mouseX, mouseY, r)) {
                        Item it = items.get(r[4]);
                        n = it.name;
                        if (it.tab == 2) target = moduleByName(n);
                    }
                }
            }
            if (target == null && n == null && !inside(mouseX, mouseY, px, py, pw, ph)) {
                for (int i = HudModules.ALL.size() - 1; i >= 0 && target == null; i--) {
                    HudModule m = HudModules.ALL.get(i);
                    if (m.enabled() && inside(mouseX, mouseY, m.px(sw), m.py(sh), m.ew(), m.eh())) target = m;
                }
            }
            if (target != null) openDetail(target);
            else if (n != null) { infoName = n; infoText = Info.get(n); }
            else infoName = null;
        }
        wasRight = rdown;

        boolean down = GLFW.glfwGetMouseButton(h, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        if (down && !wasDown && a >= 1f) {
            if (inside(mouseX, mouseY, px, py, pw, TITLE_H)) {
                collapsed = !collapsed;
            } else if (inside(mouseX, mouseY, px, py, pw, ph)) {
                if (!collapsed) {
                    if (selModule != null) {
                        if (inside(mouseX, mouseY, backR)) {
                            selModule = null;
                        } else {
                            for (int[] r : rects) {
                                if (inside(mouseX, mouseY, r)) {
                                    detail.get(r[4]).action.run();
                                    Config.save();
                                }
                            }
                        }
                    } else {
                        for (int i = 0; i < TABS.length; i++) {
                            if (inside(mouseX, mouseY, px + PAD + i * (tabW + GAP), py + TITLE_H + 1, tabW, TAB_H - 2)) {
                                tab = i;
                                page = 0;
                                infoName = null;
                                search.setFocused(false);
                            }
                        }
                        for (int[] r : rects) {
                            if (inside(mouseX, mouseY, r)) {
                                items.get(r[4]).action.run();
                                Config.save();
                            }
                        }
                        if (inside(mouseX, mouseY, prevR)) page = Math.max(0, page - 1);
                        if (inside(mouseX, mouseY, nextR)) page++;
                    }
                }
            } else {
                for (int i = HudModules.ALL.size() - 1; i >= 0; i--) {
                    HudModule m = HudModules.ALL.get(i);
                    if (!m.enabled()) continue;
                    int x = m.px(sw), y = m.py(sh);
                    if (inside(mouseX, mouseY, x, y, m.ew(), m.eh())) {
                        dragging = m;
                        offX = mouseX - x;
                        offY = mouseY - y;
                        break;
                    }
                }
            }
        }
        if (!down && dragging != null) {
            Config.save();
            dragging = null;
        }
        if (dragging != null) {
            dragging.cfg().x = Math.max(0, Math.min(mouseX - offX, sw - dragging.ew()));
            dragging.cfg().y = Math.max(0, Math.min(mouseY - offY, sh - dragging.eh()));
        }
        wasDown = down;
    }

    @Override
    public void removed() {
        Config.save();
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
