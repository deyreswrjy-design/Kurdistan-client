package dev.kurdistan.client.hud;

import dev.kurdistan.client.EditorScreen;
import dev.kurdistan.client.KurdistanClient;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.Identifier;

public final class HudRenderer {
    public static void register() {
        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT,
                Identifier.of(KurdistanClient.ID, "hud"), (ctx, tickCounter) -> {
                    if (MinecraftClient.getInstance().currentScreen instanceof EditorScreen) return;
                    render(ctx, false);
                });
    }

    public static void render(DrawContext ctx, boolean editing) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        if (!editing && mc.options.hudHidden) return;

        HudModules.update();
        int sw = ctx.getScaledWindowWidth(), sh = ctx.getScaledWindowHeight();
        for (HudModule m : HudModules.ALL) {
            if (m.enabled()) m.draw(ctx, m.px(sw), m.py(sh));
        }
    }
}
