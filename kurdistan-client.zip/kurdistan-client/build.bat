@echo off
REM Needs JDK 21. Installs the Gradle wrapper on first run, then builds.
if not exist gradlew.bat (
  where gradle >nul 2>nul || (echo Install Gradle 9.x first: https://gradle.org/install & exit /b 1)
  gradle wrapper --gradle-version 9.2.0
)
call gradlew.bat build
echo.
echo Your jar is in build\libs\kurdistan-client-1.0.0.jar
pause
